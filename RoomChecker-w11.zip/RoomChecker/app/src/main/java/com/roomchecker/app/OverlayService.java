package com.roomchecker.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.os.Process;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Control: notification ke 3 buttons (ON / OFF / KILL).
 * ON  -> floating RC button aata hai. Har tap pe turant ek scan.
 * OFF -> floating button hat jata hai.
 * KILL -> list wipe + pura app band.
 */
public class OverlayService extends Service {
    private static final String ACTION_ON = "com.roomchecker.app.ON";
    private static final String ACTION_OFF = "com.roomchecker.app.OFF";
    private static final String ACTION_KILL = "com.roomchecker.app.KILL";

    private WindowManager wm;
    private TextView bubble;
    private ResultView resultView;
    private WindowManager.LayoutParams bubbleLp, resultLp;
    private boolean bubbleShown = false;
    private boolean busy = false;
    private boolean killed = false;
    private boolean infoOn = true;
    private final List<View> approveViews = new ArrayList<>();
    private LinearLayout panelView;
    private boolean panelAdded = false;
    private List<NameMatch.Item> lastItems;
    private String lastSum = "";
    private NameMatch.Scan lastScan;
    private int lastCx, lastCy;
    private Capture capture;
    private TextRecognizer recognizer;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        if (i == null) return START_NOT_STICKY;
        String a = i.getAction();
        if (ACTION_ON.equals(a)) {
            showBubble();
        } else if (ACTION_OFF.equals(a)) {
            hideBubble();
        } else if (ACTION_KILL.equals(a)) {
            kill();
        } else if (i.hasExtra("code") && capture == null) {
            try {
                int code = i.getIntExtra("code", 0);
                Intent data = i.getParcelableExtra("data");
                capture = new Capture(this, wm, code, data);
                refreshNotification();
            } catch (Exception e) {
                Toast.makeText(this, "Screen capture shuru nahi hua: " + e.getMessage(), Toast.LENGTH_LONG).show();
                stopSelf();
            }
        }
        return START_NOT_STICKY;
    }

    @Override public void onCreate() {
        super.onCreate();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Registry.loadIfEmpty(this);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        makeResultView();
        makeBubble();
    }

    // ---------- notification ----------
    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("rc", "Room Checker", NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this, "rc")
                .setContentTitle("Room Checker")
                .setContentText(bubbleShown ? "ON: RC button dabake check karo" : "OFF: ON dabao")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .addAction(action("ON", ACTION_ON, android.R.drawable.ic_media_play))
                .addAction(action("OFF", ACTION_OFF, android.R.drawable.ic_media_pause))
                .addAction(action("KILL", ACTION_KILL, android.R.drawable.ic_delete))
                .build();
    }

    private Notification.Action action(String title, String act, int icon) {
        Intent i = new Intent(this, OverlayService.class).setAction(act);
        PendingIntent pi = PendingIntent.getService(this, act.hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi).build();
    }

    private void refreshNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(1, buildNotification());
    }

    // ---------- views ----------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private void makeResultView() {
        resultView = new ResultView(this);
        resultLp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        resultLp.gravity = Gravity.TOP | Gravity.START;
    }

    private void makeBubble() {
        bubble = new TextView(this);
        bubble.setText("RC");
        bubble.setTextColor(Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xCC2979FF);
        bubble.setBackground(bg);
        bubbleLp = new WindowManager.LayoutParams(dp(52), dp(52),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = 0;
        bubbleLp.y = dp(120);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;
            boolean longFired;
            final Runnable longPress = new Runnable() {
                @Override public void run() { if (!moved) { longFired = true; toggleInfo(); } }
            };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bubbleLp.x; sy = bubbleLp.y;
                        tx = e.getRawX(); ty = e.getRawY();
                        moved = false;
                        longFired = false;
                        v.postDelayed(longPress, 600);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) { moved = true; v.removeCallbacks(longPress); }
                        if (moved && bubbleShown) {
                            bubbleLp.x = sx + (int) dx;
                            bubbleLp.y = sy + (int) dy;
                            wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        v.removeCallbacks(longPress);
                        if (!moved && !longFired) scan();
                        return true;
                }
                return false;
            }
        });
    }

    // ---------- ON / OFF ----------
    private void showBubble() {
        if (bubbleShown) return;
        if (capture == null) {
            Toast.makeText(this, "Screen capture nahi mila. App kholke START dabao", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            capture.ensure();
        } catch (Exception e) {
            Toast.makeText(this, "Capture shuru nahi hua: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        wm.addView(resultView, resultLp);
        wm.addView(bubble, bubbleLp);
        bubbleShown = true;
        refreshNotification();
    }

    private void hideBubble() {
        if (!bubbleShown) return;
        NameMatch.resetSession();
        clearApproveViews();
        removePanel();
        lastItems = null;
        resultView.set(new ArrayList<NameMatch.Item>(), "");
        try { wm.removeView(bubble); } catch (Exception ignored) {}
        try { wm.removeView(resultView); } catch (Exception ignored) {}
        bubbleShown = false;
        if (capture != null) capture.pause();
        refreshNotification();
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (bubbleShown && capture != null) {
            try { capture.ensure(); } catch (Exception ignored) {}
        }
    }

    private void toggleInfo() {
        infoOn = !infoOn;
        resultView.setInfoVisible(infoOn);
        if (infoOn) {
            if (lastItems != null && bubbleShown) showPanel(lastItems, lastSum);
        } else {
            removePanel();
        }
        Toast.makeText(this, infoOn ? "Info panel ON" : "Info panel OFF", Toast.LENGTH_SHORT).show();
    }

    // ---------- scan (har tap pe, bina delay) ----------
    private void scan() {
        if (busy || capture == null || !bubbleShown) return;
        busy = true;
        clearApproveViews();
        removePanel();
        if (!resultView.hasMarks()) { doScan(); return; }
        // purane marks screenshot mein aa jate hain aur OCR bigadte hain: pehle hatao, fresh frame lo
        resultView.set(new ArrayList<NameMatch.Item>(), "");
        final int start = capture.frames();
        final long t0 = SystemClock.uptimeMillis();
        bubble.postDelayed(new Runnable() {
            @Override public void run() {
                long dt = SystemClock.uptimeMillis() - t0;
                if ((dt >= 110 && capture.frames() > start) || dt >= 300) doScan();
                else bubble.postDelayed(this, 10);
            }
        }, 110);
    }

    private void doScan() {
        Bitmap full = null;
        try { full = capture.grab(); } catch (Exception ignored) {}
        if (full == null) {
            busy = false;
            Toast.makeText(this, "Frame nahi mila, dobara tap karo", Toast.LENGTH_SHORT).show();
            return;
        }
        int W = full.getWidth(), H = full.getHeight();
        if (W < H) {
            resultView.set(new ArrayList<NameMatch.Item>(), "Room screen kholo");
            busy = false;
            return;
        }
        final int cx = (int) (NameMatch.CROP_L * W), cy = (int) (NameMatch.CROP_T * H);
        final int cw = (int) ((NameMatch.CROP_R - NameMatch.CROP_L) * W);
        final int ch = (int) ((NameMatch.CROP_B - NameMatch.CROP_T) * H);
        final Bitmap crop = Bitmap.createBitmap(full, cx, cy, cw, ch);
        bubble.setText("..");
        recognizer.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener(text -> {
                    NameMatch.Scan sc = NameMatch.prepare(text, cw, ch, crop);
                    retryMissing(sc, crop, 0, cx, cy);
                })
                .addOnFailureListener(e -> {
                    bubble.setText("RC");
                    busy = false;
                });
    }

    /** OCR ne jo text-jaisi lines nahi padhi, unko chhote crop mein 2x bada karke dobara padho. */
    private void retryMissing(final NameMatch.Scan sc, final Bitmap crop, final int idx, final int cx, final int cy) {
        if (idx >= sc.miss.size() || idx >= 6) {
            showResult(sc, cx, cy);
            return;
        }
        int[] m = sc.miss.get(idx);
        int l = Math.max(0, m[0] - 10), t = Math.max(0, m[1] - 8);
        int r = Math.min(crop.getWidth(), m[2] + 10), b = Math.min(crop.getHeight(), m[3] + 8);
        if (r - l < 16 || b - t < 16) {
            retryMissing(sc, crop, idx + 1, cx, cy);
            return;
        }
        final int ol = l, ot = t;
        Bitmap sub = Bitmap.createBitmap(crop, l, t, r - l, b - t);
        Bitmap big = Bitmap.createScaledBitmap(sub, sub.getWidth() * 2, sub.getHeight() * 2, true);
        recognizer.process(InputImage.fromBitmap(big, 0))
                .addOnSuccessListener(text -> {
                    NameMatch.addRetry(sc, text, ol, ot, 2);
                    retryMissing(sc, crop, idx + 1, cx, cy);
                })
                .addOnFailureListener(e -> retryMissing(sc, crop, idx + 1, cx, cy));
    }

    private void showResult(NameMatch.Scan sc, int cx, int cy) {
        lastScan = sc;
        lastCx = cx;
        lastCy = cy;
        List<NameMatch.Item> items = NameMatch.finish(sc);
        int g = 0, y = 0, r = 0, bn = 0;
        for (NameMatch.Item it : items) {
            it.rect.offset(cx, cy);
            if (it.status == NameMatch.GREEN) g++;
            else if (it.status == NameMatch.RED) r++;
            else if (it.status == NameMatch.BANNED) bn++;
            else y++;
        }
        String sum = items.isEmpty() ? "Naam nahi mile" : "G" + g + "  R" + r + "  Y" + y + (bn > 0 ? "  B" + bn : "");
        resultView.set(items, sum);
        lastItems = items;
        lastSum = sum;
        showPanel(items, sum);
        bubble.setText("RC");
        busy = false;
    }

    // ---------- panel: har yellow ke saath ek tick button = registered maano ----------
    private TextView tv(String text, int color, float px, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void removePanel() {
        if (panelAdded && panelView != null) {
            try { wm.removeView(panelView); } catch (Exception ignored) { }
        }
        panelAdded = false;
    }

    private void showPanel(List<NameMatch.Item> items, String summary) {
        removePanel();
        if (!bubbleShown || !infoOn) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(5), dp(3), dp(5), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(6));
        bg.setColor(0xF2101216);
        bg.setStroke(1, 0x66FFFFFF);
        root.setBackground(bg);
        root.addView(tv(summary, Color.WHITE, 30f, true));
        for (NameMatch.Item it : items) {
            if (it.status == NameMatch.BANNED && it.serial != -1) {
                root.addView(tv("BAN mila: #" + it.serial + " " + Registry.names.get(it.serial), Color.WHITE, 19f, true));
            }
        }

        List<NameMatch.Item> ys = new ArrayList<>();
        for (NameMatch.Item it : items) {
            if (it.tag > 0 && it.read != null) ys.add(it);
        }
        Collections.sort(ys, (a, b) -> a.tag - b.tag);
        for (final NameMatch.Item it : ys) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(3), 0, 0);
            TextView ok = tv("\u2713", Color.WHITE, 22f, true);
            ok.setGravity(Gravity.CENTER);
            GradientDrawable obg = new GradientDrawable();
            obg.setCornerRadius(dp(6));
            obg.setColor(0xFF2E7D32);
            ok.setBackground(obg);
            ok.setOnClickListener(v -> approveItem(it));
            LinearLayout.LayoutParams okp = new LinearLayout.LayoutParams(dp(34), dp(34));
            okp.rightMargin = dp(6);
            row.addView(ok, okp);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(tv(it.tag + ") " + it.read, 0xFFFFEB3B, 19f, false));
            col.addView(tv(it.hint == null ? "" : it.hint, 0xFF80DEEA, 19f, false));
            row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            root.addView(row);
        }
        for (String s : NameMatch.poolInfo) {
            if (s.isEmpty()) continue;
            root.addView(tv(s.substring(1), s.charAt(0) == 'p' ? 0xFFCFD8DC : Color.WHITE, 19f, false));
        }
        if (NameMatch.approvedCount() > 0) {
            TextView undo = tv("\u21A9 Undo aakhri (" + NameMatch.approvedCount() + ")", 0xFFFFAB91, 19f, false);
            undo.setPadding(0, dp(6), 0, dp(2));
            undo.setOnClickListener(v -> {
                NameMatch.undoLastApproval();
                Registry.saveApprovals(this);
                Toast.makeText(this, "Aakhri approve hata diya", Toast.LENGTH_SHORT).show();
                bubble.post(() -> {
                    if (lastScan != null) showResult(lastScan, lastCx, lastCy);
                });
            });
            root.addView(undo);
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = Math.min((int) (dm.widthPixels * 0.30f), 480);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = 6;
        p.y = 6;
        try {
            wm.addView(root, p);
            panelView = root;
            panelAdded = true;
        } catch (Exception ignored) { }
    }

    private void approveItem(NameMatch.Item item) {
        boolean saved = NameMatch.approve(item);
        Registry.saveApprovals(this);
        Toast.makeText(this, saved ? "Registered maan liya (" + item.tag + ")" : "Ye naam yaad nahi rakh paya", Toast.LENGTH_SHORT).show();
        bubble.post(() -> {
            if (lastScan != null) showResult(lastScan, lastCx, lastCy);
        });
    }

    // ---------- (purana) yellow badge pe lamba dabao: ab use nahi hota ----------
    private void clearApproveViews() {
        for (View v : approveViews) {
            try { wm.removeView(v); } catch (Exception ignored) { }
        }
        approveViews.clear();
    }

    private void addApproveViews(List<NameMatch.Item> items) {
        clearApproveViews();
        if (!bubbleShown) return;
        int[] loc = new int[2];
        resultView.getLocationOnScreen(loc);
        int sz = dp(44);
        for (NameMatch.Item it : items) {
            if (it.tag <= 0) continue;
            final NameMatch.Item item = it;
            View v = new View(this);
            v.setOnLongClickListener(x -> {
                NameMatch.approve(item);
                Toast.makeText(this, "Registered maan liya (" + item.tag + ")", Toast.LENGTH_SHORT).show();
                bubble.post(() -> {
                    if (lastScan != null) showResult(lastScan, lastCx, lastCy);
                });
                return true;
            });
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(sz, sz,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            p.gravity = Gravity.TOP | Gravity.START;
            p.x = it.rect.left - sz / 2 - loc[0];
            p.y = it.rect.top - sz / 2 - loc[1];
            try {
                wm.addView(v, p);
                approveViews.add(v);
            } catch (Exception ignored) { }
        }
    }

    // ---------- KILL ----------
    private void kill() {
        killed = true;
        Registry.wipe(this);
        NameMatch.resetApprovals();
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        clearApproveViews();
        removePanel();
        try { if (bubbleShown) wm.removeView(bubble); } catch (Exception ignored) {}
        try { if (bubbleShown) wm.removeView(resultView); } catch (Exception ignored) {}
        bubbleShown = false;
        if (capture != null) capture.release();
        if (recognizer != null) recognizer.close();
        super.onDestroy();
        if (killed) Process.killProcess(Process.myPid()); // pura refresh
    }
}
