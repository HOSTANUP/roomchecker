package com.roomchecker.app;

import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

/** Quick Settings tile: dabao = chalu (notification mein ON/OFF/KILL), lamba dabao = naam wali screen. */
public class RoomTileService extends TileService {

    @Override
    public void onStartListening() { refresh(); }

    @Override
    public void onTileAdded() { refresh(); }

    private void refresh() {
        Tile t = getQsTile();
        if (t == null) return;
        boolean run = OverlayService.running;
        t.setLabel("Room Checker");
        t.setState(run ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        if (Build.VERSION.SDK_INT >= 29) {
            t.setSubtitle(run ? (OverlayService.bubbleOn ? "ON" : "OFF") : "Band");
        }
        t.updateTile();
    }

    @Override
    public void onClick() {
        if (OverlayService.running) {
            Toast.makeText(this, "Chalu hai. Notification mein ON / OFF / KILL hai", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, CaptureActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivityAndCollapse(i);
    }
}
