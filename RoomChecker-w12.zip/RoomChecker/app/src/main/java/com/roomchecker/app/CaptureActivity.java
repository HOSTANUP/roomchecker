package com.roomchecker.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

/** Tile dabane pe: naam + permission check, screen capture allow karwana, phir service chalu. */
public class CaptureActivity extends Activity {
    private static final int CAPTURE = 21;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Registry.loadIfEmpty(this);
        if (Registry.count() == 0) {
            Toast.makeText(this, "Pehle naam paste karke Save karo", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'Draw over other apps' ON karo, phir tile dobara dabao", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            finish();
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), CAPTURE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == CAPTURE && res == RESULT_OK && data != null) {
            Intent svc = new Intent(this, OverlayService.class);
            svc.putExtra("code", res);
            svc.putExtra("data", data);
            startForegroundService(svc);
        } else {
            Toast.makeText(this, "Screen capture allow karna zaroori hai", Toast.LENGTH_LONG).show();
        }
        finish();
    }
}
