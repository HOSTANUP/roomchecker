package com.roomchecker.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private TextView bubble, status;
    private LinearLayout panel;
    private WindowManager.LayoutParams bubbleLp, panelLp;
    private boolean panelShown = false;
    private boolean on = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) { return START_NOT_STICKY; }

    @Override public void onCreate() {
        super.onCreate();
        startForeground(1, buildNotification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        makeBubble();
        makePanel();
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("rc", "Room Checker", NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this, "rc")
                .setContentTitle("Room Checker chal raha hai")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private WindowManager.LayoutParams lp(int w, int h) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }

    private void makeBubble() {
        bubble = new TextView(this);
        bubble.setText("RC");
        bubble.setTextColor(Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xCC2979FF);
        bubble.setBackground(bg);
        bubbleLp = lp(dp(52), dp(52));
        bubbleLp.x = 0;
        bubbleLp.y = dp(120);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bubbleLp.x; sy = bubbleLp.y;
                        tx = e.getRawX(); ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            bubbleLp.x = sx + (int) dx;
                            bubbleLp.y = sy + (int) dy;
                            wm.updateViewLayout(bubble, bubbleLp);
                            if (panelShown) { placePanel(); wm.updateViewLayout(panel, panelLp); }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel();
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleLp);
    }

    private void makePanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(0xE6101820);
        panel.setBackground(bg);
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setText("Status: OFF | List: " + Registry.count());
        panel.addView(status);
        panel.addView(btn("ON", 0xFF2E7D32, v -> { on = true; status.setText("Status: ON | List: " + Registry.count()); }));
        panel.addView(btn("OFF", 0xFFF9A825, v -> { on = false; status.setText("Status: OFF | List: " + Registry.count()); }));
        panel.addView(btn("KILL APP", 0xFFC62828, v -> { Registry.clear(); stopForeground(true); stopSelf(); }));
        panelLp = lp(dp(150), WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private Button btn(String t, int color, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        g.setColor(color);
        b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        p.topMargin = dp(6);
        b.setLayoutParams(p);
        b.setOnClickListener(c);
        return b;
    }

    private void placePanel() {
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int right = bubbleLp.x + dp(58);
        panelLp.x = (right + dp(150) > screenW) ? bubbleLp.x - dp(156) : right;
        panelLp.y = bubbleLp.y;
    }

    private void togglePanel() {
        if (panelShown) {
            wm.removeView(panel);
        } else {
            placePanel();
            wm.addView(panel, panelLp);
        }
        panelShown = !panelShown;
    }

    @Override public void onDestroy() {
        try { if (panelShown) wm.removeView(panel); } catch (Exception ignored) {}
        try { wm.removeView(bubble); } catch (Exception ignored) {}
        panelShown = false;
        super.onDestroy();
    }
}
