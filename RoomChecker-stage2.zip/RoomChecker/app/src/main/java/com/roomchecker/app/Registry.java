package com.roomchecker.app;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/** Registered list: sirf RAM mein. KILL pe clear() hota hai. */
public class Registry {
    public static final TreeMap<Integer, String> names = new TreeMap<>();

    public static int count() { return names.size(); }
    public static int maxSerial() { return names.isEmpty() ? 0 : names.lastKey(); }
    public static void clear() { names.clear(); }

    /** Khali ya jisme koi letter/digit nahi: OCR ne padha nahi. */
    public static boolean doubtful(String s) {
        return s == null || !s.matches("(?s).*[A-Za-z0-9].*");
    }

    public static List<Integer> missing() {
        List<Integer> m = new ArrayList<>();
        for (int i = 1; i <= maxSerial(); i++) if (!names.containsKey(i)) m.add(i);
        return m;
    }
}
