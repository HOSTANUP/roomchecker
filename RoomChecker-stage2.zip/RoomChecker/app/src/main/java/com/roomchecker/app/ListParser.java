package com.roomchecker.app;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** BattleX11 "Match Details" screenshot se serial -> naam nikalta hai. */
public class ListParser {
    private static final Pattern SERIAL_ONLY = Pattern.compile("^\\s*(\\d{1,2})\\s*[.,:]?\\s*$");
    private static final Pattern SERIAL_NAME = Pattern.compile("^\\s*(\\d{1,2})\\s*[.,:]\\s*(.+)$");

    private static class Row {
        int serial, cy;
        String inline = "";
        List<Text.Line> parts = new ArrayList<>();
    }

    public static Map<Integer, String> parse(Text text, int w, int h) {
        List<Row> rows = new ArrayList<>();
        List<Text.Line> others = new ArrayList<>();
        for (Text.TextBlock b : text.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                Rect bb = l.getBoundingBox();
                if (bb == null) continue;
                int cy = bb.centerY();
                // header (Match Details) aur neeche ka JOIN bar ignore
                if (cy < 0.10 * h || cy > 0.88 * h) continue;
                String t = l.getText();
                if (bb.left < 0.2 * w) {
                    Matcher m1 = SERIAL_ONLY.matcher(t);
                    if (m1.matches()) {
                        Row r = new Row();
                        r.serial = Integer.parseInt(m1.group(1));
                        r.cy = cy;
                        rows.add(r);
                        continue;
                    }
                    Matcher m2 = SERIAL_NAME.matcher(t);
                    if (m2.matches()) {
                        Row r = new Row();
                        r.serial = Integer.parseInt(m2.group(1));
                        r.cy = cy;
                        r.inline = m2.group(2).trim();
                        rows.add(r);
                        continue;
                    }
                }
                others.add(l);
            }
        }
        double tol = 0.028 * h;
        for (Text.Line l : others) {
            Rect bb = l.getBoundingBox();
            Row best = null;
            double bd = 1e9;
            for (Row r : rows) {
                double d = Math.abs(bb.centerY() - r.cy);
                if (d < bd) { bd = d; best = r; }
            }
            if (best != null && bd <= tol) best.parts.add(l);
        }
        Map<Integer, String> out = new LinkedHashMap<>();
        for (Row r : rows) {
            Collections.sort(r.parts, new Comparator<Text.Line>() {
                @Override public int compare(Text.Line a, Text.Line b) {
                    return a.getBoundingBox().left - b.getBoundingBox().left;
                }
            });
            StringBuilder sb = new StringBuilder(r.inline);
            for (Text.Line p : r.parts) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(p.getText().trim());
            }
            String name = sb.toString().trim();
            String old = out.get(r.serial);
            if (old == null || (Registry.doubtful(old) && !Registry.doubtful(name))) out.put(r.serial, name);
        }
        return out;
    }
}
