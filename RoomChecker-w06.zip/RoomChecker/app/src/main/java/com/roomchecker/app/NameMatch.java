package com.roomchecker.app;

import android.graphics.Bitmap;
import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Room ke naam vs registered list.
 * Symbols hata ke bache hue akshar compare hote hain. GREEN = lagbhag pura match,
 * RED = kisi registered se milta hi nahi (ya kisi registered ki copy jaisa), baaki sab YELLOW.
 */
public class NameMatch {
    public static final int GREEN = 0, YELLOW = 1, RED = 2;
    // Room list ka bada area; asli list slot numbers se dhoondhi jaati hai
    public static final double CROP_L = 0.25, CROP_R = 1.0, CROP_T = 0.17, CROP_B = 0.78;
    // list ke andar naam ka text kahan tak poora dikhta hai (screen height ke hisse mein)
    public static final double LIST_TOP = 0.195, LIST_BOT_L = 0.735, LIST_BOT_R = 0.755;

    public static class Item {
        public Rect rect;
        public int status;
        public int tag;
        public String key;
        public long[] print;
        public int serial = -1;
        public String read, hint;
    }

    private static class Alias { int serial; String n; }
    private static class El { String t; Rect bb; }
    private static class Group {
        int col, cy;
        Rect box;
        List<El> lines = new ArrayList<>();
        String raw = "", n = "";
        boolean clean;
        int serial = -1, status = YELLOW;
        double matchSim = 0;
        int tag;
        int hintSerial = -1;
        String readTxt, hintTxt;
        Map<Integer, Double> simBy = new HashMap<>();
    }
    private static class Pair { Group g; int serial; double s; int max; }

    private static final String SC_FROM = "\u1D00\u0299\u1D04\u1D05\u1D07\uA730\u0262\u029C\u026A\u1D0A\u1D0B\u029F\u1D0D\u0274\u1D0F\u1D18\u01EB\u0280\uA731\u1D1B\u1D1C\u1D20\u1D21\u028F\u1D22";
    private static final String SC_TO = "abcdefghijklmnopqrstuvwyz";

    // look-alike letters: (non-latin letter)(latin letter) jodiyon mein
    private static final Map<Character, Character> CF = new HashMap<>();
    static {
        String s = "\u13AAa\u13F4b\u13DFc\u13A0d\u13ACe\u13C0g\u13BBh\u13ABj\u13E6k\u13DEl\u13B7m\u13E2p\u13A1r\u13DAs\u13A2t\u13D9v\u13B3w\u13C3z\u13A9y"
                + "\u0430a\u0435e\u043Eo\u0440p\u0441c\u0443y\u0445x\u043Ak\u043Cm\u043Dh\u0442t\u0432b"
                + "\u0410a\u0412b\u0415e\u041Ak\u041Cm\u041Dh\u041Eo\u0420p\u0421c\u0422t\u0425x\u0423y"
                + "\u03B1a\u03B2b\u03B5e\u03B9i\u03BAk\u03BDv\u03BFo\u03C1p\u03C3o\u03C4t\u03C5u\u03C9w\u03C7x"
                + "\u0391a\u0392b\u0395e\u0396z\u0397h\u0399i\u039Ak\u039Cm\u039Dn\u039Fo\u03A1p\u03A4t\u03A7x\u03A5y"
                + "\u03A3e\u03B7n\u10E7y\u0251a\u0261g\u0131i\u204At"
                + "\u15E9a\u15F7b\u1455c\u15EAd\u15F4e\u15B4f\u161Cg\u157Ch\u148Dj\u14AAl\u15F0m\u144En\u146Dp\u1587r\u1515s\u144Cu\u142Fv\u15EFw";
        for (int i = 0; i + 1 < s.length(); i += 2) CF.put(s.charAt(i), s.charAt(i + 1));
    }

    /** Panel ke liye: yellow ka hint aur "nahi dikhe" list. */
    public static List<String> info = new ArrayList<>();
    /** Panel ke neeche "nahi dikhe" wali lines (pehla akshar rang: w/p). */
    public static List<String> poolInfo = new ArrayList<>();
    private static final Set<Integer> sessionGreen = new HashSet<>();

    /** Naya sweep: pehle dekhe hue registered bhool jao. */
    public static void resetSession() {
        sessionGreen.clear();
        info = new ArrayList<>();
        poolInfo = new ArrayList<>();
    }

    private static String cut(String s, int n) {
        if (s == null) return "";
        if (s.codePointCount(0, s.length()) <= n) return s;
        return s.substring(0, s.offsetByCodePoints(0, n)) + "...";
    }

    private static String pctName(int serial, double sim) {
        return "#" + serial + " " + cut(Registry.names.get(serial), 60) + " " + Math.round(sim * 100) + "%";
    }

    private static final Map<Character, Character> LB = new HashMap<>();

    /** "LATIN CAPITAL LETTER N WITH LEFT HOOK" jaise akshar ka base letter (n). */
    private static char latinBase(char c) {
        Character hit = LB.get(c);
        if (hit != null) return hit;
        char r = 0;
        try {
            String nm = Character.getName(c);
            if (nm != null && nm.startsWith("LATIN")) {
                int i = nm.indexOf("SMALL CAPITAL ");
                int li = nm.indexOf("LETTER ");
                int k = i >= 0 ? i + 14 : (li >= 0 ? li + 7 : -1);
                if (k >= 0 && k < nm.length()) {
                    int e = nm.indexOf(' ', k);
                    String tok = e < 0 ? nm.substring(k) : nm.substring(k, e);
                    if (tok.length() == 1 && tok.charAt(0) >= 'A' && tok.charAt(0) <= 'Z') {
                        r = Character.toLowerCase(tok.charAt(0));
                    }
                }
            }
        } catch (Throwable ignored) { }
        LB.put(c, r);
        return r;
    }

    /** Stylish/leet naam ko simple form mein badalta hai (4nup == Anup). */
    public static String norm(String s) {
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFKD);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int k = SC_FROM.indexOf(c);
            if (k >= 0) c = SC_TO.charAt(k);
            Character cf = CF.get(c);
            if (cf != null) {
                c = cf;
            } else if (c > 0x7F) {
                char lb = latinBase(c);
                if (lb != 0) c = lb;
            }
            c = Character.toLowerCase(c);
            switch (c) {
                case '4': c = 'a'; break;
                case '0': c = 'o'; break;
                case '3': c = 'e'; break;
                case '1': case 'l': case '!': case '|': c = 'i'; break;
                case '5': case '$': c = 's'; break;
                case '7': c = 't'; break;
                case '8': c = 'b'; break;
                default: break;
            }
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) sb.append(c);
        }
        return sb.toString();
    }

    private static int lcs(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) cur[j] = prev[j - 1] + 1;
                else cur[j] = Math.max(prev[j], cur[j - 1]);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    /** 0..1: kitne akshar (sequence mein) common hain. */
    private static double sim(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        if (a.equals(b)) return 1.0;
        double s = 2.0 * lcs(a, b) / (a.length() + b.length());
        String shorter = a.length() <= b.length() ? a : b;
        String longer = a.length() <= b.length() ? b : a;
        if (shorter.length() >= 3 && longer.contains(shorter)) s = Math.max(s, 0.7);
        return s;
    }

    private static List<Alias> buildAliases() {
        List<Alias> out = new ArrayList<>();
        for (Map.Entry<Integer, String> e : Registry.names.entrySet()) {
            String raw = e.getValue();
            if (raw == null) continue;
            String full = norm(raw);
            if (!full.isEmpty()) addAlias(out, e.getKey(), full);
            String seenTxt = Registry.seen.get(e.getKey());
            if (seenTxt != null) {
                String sn = norm(seenTxt);
                if (sn.length() >= 3 && !sn.equals(full)) addAlias(out, e.getKey(), sn);
            }
            String[] parts = raw.split("[/|]");
            if (parts.length > 1) {
                for (String p : parts) {
                    String n = norm(p);
                    if (n.length() >= 3 && !n.equals(full)) addAlias(out, e.getKey(), n);
                }
            }
        }
        return out;
    }

    private static void addAlias(List<Alias> out, int serial, String n) {
        Alias a = new Alias();
        a.serial = serial;
        a.n = n;
        out.add(a);
    }

    // ---------- room ke naam dhoondhna (shabd-level: ML Kit ke line-merge se farak nahi padta) ----------
    private static List<El> elements(Text text) {
        List<El> out = new ArrayList<>();
        for (Text.TextBlock b : text.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                for (Text.Element e : l.getElements()) {
                    Rect bb = e.getBoundingBox();
                    if (bb == null) continue;
                    El x = new El();
                    x.t = e.getText();
                    x.bb = bb;
                    out.add(x);
                }
            }
        }
        return out;
    }

    private static double meanLeft(List<El> c) {
        double s = 0;
        for (El e : c) s += e.bb.left;
        return s / c.size();
    }

    private static double meanRight(List<El> c) {
        double s = 0;
        for (El e : c) s += e.bb.right;
        return s / c.size();
    }

    private static int median(List<Integer> v) {
        Collections.sort(v);
        return v.get(v.size() / 2);
    }

    // pichhli baar ke columns (width ke hisse mein): agar is baar slot numbers na padhe jaayein
    private static double[] lastGeom = null;

    /** Slot numbers ke do columns: {m1, nr1, m2, nr2} = left/right edge ka average. */
    private static double[] geom(List<El> all, int w) {
        List<El> nums = new ArrayList<>();
        for (El e : all) {
            String t = e.t.trim();
            if (t.matches("\\d{1,2}")) {
                int v = Integer.parseInt(t);
                if (v >= 1 && v <= 60) nums.add(e);
            }
        }
        double[] res = null;
        if (nums.size() >= 4) {
            Collections.sort(nums, new Comparator<El>() {
                @Override public int compare(El a, El b) { return a.bb.left - b.bb.left; }
            });
            List<List<El>> cols = new ArrayList<>();
            for (El e : nums) {
                List<El> cur = cols.isEmpty() ? null : cols.get(cols.size() - 1);
                if (cur != null && e.bb.left - cur.get(0).bb.left <= 0.03 * w) {
                    cur.add(e);
                } else {
                    List<El> c = new ArrayList<>();
                    c.add(e);
                    cols.add(c);
                }
            }
            Collections.sort(cols, new Comparator<List<El>>() {
                @Override public int compare(List<El> a, List<El> b) { return b.size() - a.size(); }
            });
            if (cols.size() >= 2 && cols.get(1).size() >= 2) {
                List<El> c1 = cols.get(0), c2 = cols.get(1);
                double m1 = meanLeft(c1), m2 = meanLeft(c2);
                double r1 = meanRight(c1), r2 = meanRight(c2);
                if (m1 > m2) {
                    double t = m1; m1 = m2; m2 = t;
                    t = r1; r1 = r2; r2 = t;
                }
                if (m2 - m1 >= 0.15 * w) res = new double[]{m1, r1, m2, r2};
            }
        }
        if (res != null) {
            lastGeom = new double[]{res[0] / w, res[1] / w, res[2] / w, res[3] / w};
            return res;
        }
        if (lastGeom != null) {
            return new double[]{lastGeom[0] * w, lastGeom[1] * w, lastGeom[2] * w, lastGeom[3] * w};
        }
        return null;
    }

    /**
     * Numbers sirf columns ki jagah batate hain. Har naam (text ki har line) alag player hai:
     * solo mein 1 naam per slot, duo mein 2, squad mein 4. Kate hue rows chhod diye jaate hain.
     */
    private static List<Group> anchored(List<El> all, int w, int h) {
        double[] g = geom(all, w);
        if (g == null) return null;
        double m1 = g[0], nr1 = g[1], m2 = g[2], nr2 = g[3];
        double cellW = m2 - m1;
        double span = CROP_B - CROP_T;
        double yTop = (LIST_TOP - CROP_T) / span * h;
        double tol = 0.03 / span * h;
        List<Group> groups = new ArrayList<>();
        for (int ci = 0; ci < 2; ci++) {
            double zl = (ci == 0 ? nr1 : nr2) + 0.005 * w;
            double zr = ci == 0 ? m2 - 0.01 * w : m2 + cellW;
            double yBot = ((ci == 0 ? LIST_BOT_L : LIST_BOT_R) - CROP_T) / span * h;
            List<El> col = new ArrayList<>();
            for (El e : all) {
                double cx = e.bb.centerX();
                if (cx < zl || cx > zr) continue;
                if (e.bb.top < yTop || e.bb.bottom > yBot) continue;
                col.add(e);
            }
            Collections.sort(col, new Comparator<El>() {
                @Override public int compare(El a, El b) { return a.bb.centerY() - b.bb.centerY(); }
            });
            Group cur = null;
            int lastCy = 0;
            for (El e : col) {
                if (cur == null || e.bb.centerY() - lastCy > tol) {
                    cur = new Group();
                    cur.col = ci;
                    cur.cy = e.bb.centerY();
                    cur.box = new Rect(e.bb);
                    groups.add(cur);
                } else {
                    cur.box.union(e.bb);
                }
                cur.lines.add(e);
                lastCy = e.bb.centerY();
            }
        }
        return groups;
    }

    // ---------- tumhara "registered maana" (long press): yaad rakho ----------
    private static class Approved { String key; long[] print; int serial = -1; }
    private static final List<Approved> approved = new ArrayList<>();

    public static boolean approve(Item it) {
        boolean hasKey = it.key != null && it.key.length() >= 5;
        if (!hasKey && it.print == null) return false;
        Approved a = new Approved();
        a.key = hasKey ? it.key : null;
        a.print = it.print;
        a.serial = it.serial;
        approved.add(a);
        return true;
    }

    public static void resetApprovals() { approved.clear(); }

    public static int approvedCount() { return approved.size(); }

    /** Galti se approve ho gaya ho toh aakhri wala wapas. */
    public static void undoLastApproval() {
        if (!approved.isEmpty()) approved.remove(approved.size() - 1);
    }

    /** Row ki asli (pixel) jagah agar mile, warna OCR group ka box. */
    private static Rect runBox(Group g, List<int[]> runs) {
        if (runs != null) {
            for (int[] r : runs) {
                if (r[4] != g.col) continue;
                int ov = Math.min(g.box.bottom, r[3]) - Math.max(g.box.top, r[1]);
                if (ov >= 0.5 * (r[3] - r[1])) return new Rect(r[0], r[1], r[2], r[3]);
            }
        }
        return g.box;
    }

    /** Naam ki tasveer ka chhota "fingerprint" (48x12 grid): OCR kuch bhi padhe, tasveer wahi rehti hai. */
    private static long[] fingerprint(Bitmap bmp, Rect box) {
        int l = Math.max(0, box.left), t = Math.max(0, box.top);
        int r = Math.min(bmp.getWidth(), box.right), b = Math.min(bmp.getHeight(), box.bottom);
        if (r - l < 8 || b - t < 6) return null;
        int w = r - l, h = b - t;
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, l, t, w, h);
        int minX = w, maxX = -1, minY = h, maxY = -1;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int p = px[y * w + x];
                int mx = Math.max((p >> 16) & 255, Math.max((p >> 8) & 255, p & 255));
                if (mx >= 150) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX - minX < 6 || maxY - minY < 4) return null;
        int bw = maxX - minX + 1, bh = maxY - minY + 1;
        long[] bits = new long[9];
        for (int gy = 0; gy < 12; gy++) {
            for (int gx = 0; gx < 48; gx++) {
                int x0 = minX + gx * bw / 48, x1 = minX + (gx + 1) * bw / 48;
                int y0 = minY + gy * bh / 12, y1 = minY + (gy + 1) * bh / 12;
                if (x1 <= x0) x1 = x0 + 1;
                if (y1 <= y0) y1 = y0 + 1;
                int on = 0, tot = 0;
                for (int y = y0; y < y1 && y < h; y++) {
                    for (int x = x0; x < x1 && x < w; x++) {
                        int p = px[y * w + x];
                        int mx = Math.max((p >> 16) & 255, Math.max((p >> 8) & 255, p & 255));
                        if (mx >= 150) on++;
                        tot++;
                    }
                }
                if (tot > 0 && on * 4 >= tot) {
                    int idx = gy * 48 + gx;
                    bits[idx / 64] |= 1L << (idx % 64);
                }
            }
        }
        return bits;
    }

    private static double jaccard(long[] a, long[] b) {
        int inter = 0, uni = 0;
        for (int i = 0; i < a.length; i++) {
            inter += Long.bitCount(a[i] & b[i]);
            uni += Long.bitCount(a[i] | b[i]);
        }
        return uni == 0 ? 0 : inter / (double) uni;
    }

    private static Approved findApproved(Group g, Bitmap bmp, List<int[]> runs) {
        long[] pr = null;
        boolean done = false;
        for (Approved a : approved) {
            if (a.key != null && g.n.length() >= 5 && sim(g.n, a.key) >= 0.9) return a;
            if (a.print != null && bmp != null) {
                if (!done) {
                    pr = fingerprint(bmp, runBox(g, runs));
                    done = true;
                }
                if (pr != null && jaccard(pr, a.print) >= 0.72) return a;
            }
        }
        return null;
    }

    // ---------- jo OCR ne nahi padha: pixel se pakdo ----------
    public static class Scan {
        List<El> els = new ArrayList<>();
        Bitmap bmp;
        int w, h;
        List<int[]> runs = new ArrayList<>();
        public List<int[]> miss = new ArrayList<>();
    }

    /** Naam wale columns mein text-jaisi (bright) lines: {left, top, right, bottom, col}. */
    private static List<int[]> findRuns(Bitmap bmp, double[] g, int w, int h) {
        List<int[]> out = new ArrayList<>();
        double m1 = g[0], nr1 = g[1], m2 = g[2], nr2 = g[3];
        double cellW = m2 - m1;
        double span = CROP_B - CROP_T;
        int yTop = (int) Math.ceil((LIST_TOP - CROP_T) / span * h) + 1;
        for (int ci = 0; ci < 2; ci++) {
            int zl = (int) Math.max(0, (ci == 0 ? nr1 : nr2) + 0.005 * w);
            int zr = (int) Math.min(bmp.getWidth() - 1, ci == 0 ? m2 - 0.01 * w : m2 + cellW);
            int yBot = (int) Math.min(bmp.getHeight() - 1, ((ci == 0 ? LIST_BOT_L : LIST_BOT_R) - CROP_T) / span * h) - 1;
            if (zr - zl < 30 || yBot - yTop < 20) continue;
            int zw = zr - zl + 1;
            int n = yBot - yTop + 1;
            int[] px = new int[zw];
            int[] cnt = new int[n];
            int[] minX = new int[n];
            int[] maxX = new int[n];
            for (int y = yTop; y <= yBot; y++) {
                bmp.getPixels(px, 0, zw, zl, y, zw, 1);
                int c = 0, lo = zw, hi = -1;
                for (int x = 0; x < zw; x++) {
                    int p = px[x];
                    int mxc = Math.max((p >> 16) & 255, Math.max((p >> 8) & 255, p & 255));
                    if (mxc >= 150) {
                        c++;
                        if (x < lo) lo = x;
                        if (x > hi) hi = x;
                    }
                }
                cnt[y - yTop] = c;
                minX[y - yTop] = lo;
                maxX[y - yTop] = hi;
            }
            int k = 0;
            while (k < n) {
                if (cnt[k] < 2) { k++; continue; }
                int start = k, end = k, gap = 0, total = 0, lo = zw, hi = -1;
                int j = k;
                while (j < n && gap <= 2) {
                    if (cnt[j] >= 2) {
                        end = j;
                        gap = 0;
                        total += cnt[j];
                        lo = Math.min(lo, minX[j]);
                        hi = Math.max(hi, maxX[j]);
                    } else {
                        gap++;
                    }
                    j++;
                }
                k = end + 1;
                boolean edge = start == 0 || end == n - 1;
                if (!edge && end - start >= 7 && total >= 60 && hi - lo >= 26) {
                    out.add(new int[]{zl + lo - 6, yTop + start - 5, zl + hi + 6, yTop + end + 5, ci});
                }
            }
        }
        return out;
    }

    /** Un runs ko chhodke jinhe koi OCR-group (usi column mein, usi height pe) cover karta hai. */
    private static List<int[]> uncovered(List<int[]> runs, List<Group> groups) {
        List<int[]> out = new ArrayList<>();
        for (int[] r : runs) {
            boolean covered = false;
            for (Group g : groups) {
                if (g.col != r[4]) continue;
                int ov = Math.min(g.box.bottom, r[3]) - Math.max(g.box.top, r[1]);
                if (ov >= 0.5 * (r[3] - r[1])) { covered = true; break; }
            }
            if (!covered) out.add(r);
        }
        return out;
    }

    // ---------- matching ----------
    public static List<Item> evaluate(Text text, int w, int h) {
        return finish(prepare(text, w, h, null));
    }

    /** Pehle OCR ka result + (bitmap ho toh) woh text-jaisi lines jo OCR ne nahi padhi. */
    public static Scan prepare(Text text, int w, int h, Bitmap crop) {
        Scan sc = new Scan();
        sc.w = w;
        sc.h = h;
        sc.els = elements(text);
        sc.bmp = crop;
        if (crop != null) {
            List<Group> g0 = anchored(sc.els, w, h);
            double[] gm = geom(sc.els, w);
            if (g0 != null && gm != null) {
                sc.runs = findRuns(crop, gm, w, h);
                sc.miss = uncovered(sc.runs, g0);
            }
        }
        return sc;
    }

    /** Chhoote hue row ka dobara OCR: crop mein (ox, oy) se shuru, scale guna bada kiya hua. */
    public static void addRetry(Scan sc, Text t, int ox, int oy, int scale) {
        for (El e : elements(t)) {
            Rect b = e.bb;
            e.bb = new Rect(ox + b.left / scale, oy + b.top / scale, ox + b.right / scale, oy + b.bottom / scale);
            sc.els.add(e);
        }
    }

    public static List<Item> finish(Scan sc) {
        List<Group> groups = anchored(sc.els, sc.w, sc.h);
        if (groups == null) return new ArrayList<Item>();
        // jo text-jaisi line ab bhi nahi padhi gayi: YELLOW "padha nahi gaya", chhupne nahi dena
        for (int[] r : uncovered(sc.runs, groups)) {
            Group g = new Group();
            g.col = r[4];
            g.cy = (r[1] + r[3]) / 2;
            g.box = new Rect(r[0], r[1], r[2], r[3]);
            groups.add(g);
        }
        return match(groups, sc.bmp, sc.runs);
    }

    private static List<Item> match(List<Group> groups, Bitmap bmp, List<int[]> runs) {

        for (Group g : groups) {
            Collections.sort(g.lines, new Comparator<El>() {
                @Override public int compare(El a, El b) { return a.bb.left - b.bb.left; }
            });
            StringBuilder sb = new StringBuilder();
            for (El l : g.lines) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(l.t.trim());
            }
            g.raw = sb.toString();
            g.n = norm(g.raw);
            int ascii = 0, tot = 0;
            for (int i = 0; i < g.raw.length(); i++) {
                char c = g.raw.charAt(i);
                if (Character.isWhitespace(c)) continue;
                tot++;
                if (c >= 0x21 && c <= 0x7E) ascii++;
            }
            g.clean = g.n.length() >= 3 && tot > 0 && ascii >= 0.75 * tot;
        }

        List<Alias> aliases = buildAliases();

        // har room-naam ke liye: har registered banda se best similarity
        for (Group g : groups) {
            if (g.n.isEmpty()) continue;
            for (Alias a : aliases) {
                double sm = sim(g.n, a.n);
                Double old = g.simBy.get(a.serial);
                if (old == null || sm > old) g.simBy.put(a.serial, sm);
            }
        }
        List<Pair> pairs = new ArrayList<>();
        for (Group g : groups) {
            for (Map.Entry<Integer, Double> e : g.simBy.entrySet()) {
                if (e.getValue() >= 0.6) {
                    Pair p = new Pair();
                    p.g = g;
                    p.serial = e.getKey();
                    p.s = e.getValue();
                    p.max = g.n.length();
                    pairs.add(p);
                }
            }
        }
        Collections.sort(pairs, new Comparator<Pair>() {
            @Override public int compare(Pair x, Pair y) {
                if (x.s != y.s) return x.s > y.s ? -1 : 1;
                return y.max - x.max;
            }
        });
        // har registered banda sirf ek slot claim kar sakta hai (best match pehle)
        Set<Integer> taken = new HashSet<>();
        Map<Integer, Double> claimedSim = new HashMap<>();
        for (Pair p : pairs) {
            if (p.g.serial != -1 || taken.contains(p.serial)) continue;
            p.g.serial = p.serial;
            p.g.matchSim = p.s;
            taken.add(p.serial);
            claimedSim.put(p.serial, p.s);
        }
        // GREEN: bilkul same, ya bahut milta-julta aur koi doosra davedaar nahi
        for (Group g : groups) {
            if (g.serial == -1) continue;
            double sm = g.matchSim;
            double second = 0;
            for (Map.Entry<Integer, Double> e : g.simBy.entrySet()) {
                if (e.getKey() != g.serial && e.getValue() > second) second = e.getValue();
            }
            double rival = 0;
            for (Group o : groups) {
                if (o == g) continue;
                Double v = o.simBy.get(g.serial);
                if (v != null && v > rival) rival = v;
            }
            boolean exact = sm >= 0.999 && g.n.length() >= 2;
            boolean near = sm >= 0.85 && g.n.length() >= 6 && sm - second >= 0.15 && sm - rival >= 0.15;
            g.status = (exact || near) ? GREEN : YELLOW;
        }
        // RED: sirf pakka. Baaki shak wale YELLOW
        for (Group g : groups) {
            if (g.serial != -1) continue;
            if (g.n.isEmpty() || aliases.isEmpty()) { g.status = YELLOW; continue; }
            double best = 0;
            int bestSerial = -1;
            for (Map.Entry<Integer, Double> e : g.simBy.entrySet()) {
                if (e.getValue() > best) { best = e.getValue(); bestSerial = e.getKey(); }
            }
            Double cs = claimedSim.get(bestSerial);
            boolean copyOfClaimed = best >= 0.5 && cs != null && cs >= 0.999;
            if (g.clean && best < 0.6) g.status = RED;                       // kisi registered se milta hi nahi
            else if (!g.clean && g.n.length() >= 4 && best < 0.4) g.status = RED;
            else if (g.clean && copyOfClaimed) g.status = RED;              // asli match kisi aur slot ko mil chuka
            else g.status = YELLOW;
        }

        // ---- jinhe tumne "registered" maana: hamesha green ----
        if (!approved.isEmpty()) {
            for (Group g : groups) {
                if (g.status == GREEN) continue;
                Approved ap = findApproved(g, bmp, runs);
                if (ap != null) {
                    g.status = GREEN;
                    if (g.serial == -1 && ap.serial != -1 && !taken.contains(ap.serial)) {
                        g.serial = ap.serial;
                        taken.add(ap.serial);
                    }
                }
            }
        }
        // ---- yellow ka hint + "nahi dikhe" (registered, jo kisi scan mein green nahi hue) ----
        Set<Integer> assignedNow = new HashSet<>();
        for (Group g : groups) {
            if (g.serial != -1) {
                assignedNow.add(g.serial);
                if (g.status == GREEN) sessionGreen.add(g.serial);
            }
        }
        List<Integer> pool = new ArrayList<>();
        for (Map.Entry<Integer, String> e : Registry.names.entrySet()) {
            String nm = e.getValue();
            if (nm == null || nm.trim().isEmpty()) continue;
            if (sessionGreen.contains(e.getKey()) || assignedNow.contains(e.getKey())) continue;
            pool.add(e.getKey());
        }
        List<Group> yel = new ArrayList<>();
        for (Group g : groups) if (g.status == YELLOW) yel.add(g);
        Collections.sort(yel, new Comparator<Group>() {
            @Override public int compare(Group a, Group b) {
                if (a.cy != b.cy) return a.cy - b.cy;
                return a.col - b.col;
            }
        });
        List<String> lines = new ArrayList<>();
        int num = 0;
        for (Group g : yel) {
            g.tag = ++num;
            if (num > 4) continue;
            String read = g.raw.trim();
            if (read.isEmpty()) read = "(padha nahi gaya)";
            String hint;
            if (g.n.isEmpty()) {
                hint = "list mein dekho";
            } else if (g.serial != -1) {
                hint = pctName(g.serial, g.matchSim);
                g.hintSerial = g.serial;
            } else {
                double best = 0;
                int bs = -1;
                for (int sId : pool) {
                    Double v = g.simBy.get(sId);
                    if (v != null && v > best) { best = v; bs = sId; }
                }
                hint = (bs != -1 && best >= 0.5) ? "shayad " + pctName(bs, best) : "koi milta nahi";
                if (bs != -1 && best >= 0.5) g.hintSerial = bs;
            }
            g.readTxt = cut(read, 40);
            g.hintTxt = hint;
            lines.add("y" + g.tag + ") " + cut(read, 40));
            lines.add("h    " + hint);
        }
        if (num > 4) lines.add("y+" + (num - 4) + " yellow aur");
        if (num > 0) lines.add("wBadge lamba dabao = registered");
        if (!pool.isEmpty()) {
            if (pool.size() <= 6) {
                lines.add("wNahi dikhe (" + pool.size() + "):");
                for (int sId : pool) lines.add("p#" + sId + " " + cut(Registry.names.get(sId), 40));
            } else {
                lines.add("wNahi dikhe: " + pool.size() + " (scroll karo)");
            }
        }
        info = lines;
        List<String> pl = new ArrayList<>();
        if (!pool.isEmpty()) {
            if (pool.size() <= 6) {
                pl.add("wNahi dikhe (" + pool.size() + "):");
                for (int sId : pool) pl.add("p#" + sId + " " + cut(Registry.names.get(sId), 40));
            } else {
                pl.add("wNahi dikhe: " + pool.size() + " (scroll karo)");
            }
        }
        poolInfo = pl;

        List<Item> out = new ArrayList<>();
        for (Group g : groups) {
            Item it = new Item();
            it.rect = new Rect(g.box.left - 8, g.box.top - 5, g.box.right + 8, g.box.bottom + 5);
            it.status = g.status;
            it.tag = g.tag;
            it.key = g.n;
            it.serial = g.hintSerial;
            it.read = g.readTxt;
            it.hint = g.hintTxt;
            if (g.status == YELLOW && bmp != null) it.print = fingerprint(bmp, runBox(g, runs));
            out.add(it);
        }
        return out;
    }
}
