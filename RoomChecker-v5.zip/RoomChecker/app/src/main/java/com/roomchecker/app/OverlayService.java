package com.roomchecker.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.os.Process;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.ArrayList;
import java.util.List;

/**
 * Control: notification ke 3 buttons (ON / OFF / KILL).
 * ON  -> floating RC button aata hai. Har tap pe turant ek scan.
 * OFF -> floating button hat jata hai.
 * KILL -> list wipe + pura app band.
 */
public class OverlayService extends Service {
    private static final String ACTION_ON = "com.roomchecker.app.ON";
    private static final String ACTION_OFF = "com.roomchecker.app.OFF";
    private static final String ACTION_KILL = "com.roomchecker.app.KILL";

    private WindowManager wm;
    private TextView bubble;
    private ResultView resultView;
    private WindowManager.LayoutParams bubbleLp, resultLp;
    private boolean bubbleShown = false;
    private boolean busy = false;
    private boolean killed = false;
    private Capture capture;
    private TextRecognizer recognizer;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        if (i == null) return START_NOT_STICKY;
        String a = i.getAction();
        if (ACTION_ON.equals(a)) {
            showBubble();
        } else if (ACTION_OFF.equals(a)) {
            hideBubble();
        } else if (ACTION_KILL.equals(a)) {
            kill();
        } else if (i.hasExtra("code") && capture == null) {
            try {
                int code = i.getIntExtra("code", 0);
                Intent data = i.getParcelableExtra("data");
                capture = new Capture(this, wm, code, data);
                refreshNotification();
            } catch (Exception e) {
                Toast.makeText(this, "Screen capture shuru nahi hua: " + e.getMessage(), Toast.LENGTH_LONG).show();
                stopSelf();
            }
        }
        return START_NOT_STICKY;
    }

    @Override public void onCreate() {
        super.onCreate();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        makeResultView();
        makeBubble();
    }

    // ---------- notification ----------
    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("rc", "Room Checker", NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this, "rc")
                .setContentTitle("Room Checker")
                .setContentText(bubbleShown ? "ON: RC button dabake check karo" : "OFF: ON dabao")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .addAction(action("ON", ACTION_ON, android.R.drawable.ic_media_play))
                .addAction(action("OFF", ACTION_OFF, android.R.drawable.ic_media_pause))
                .addAction(action("KILL", ACTION_KILL, android.R.drawable.ic_delete))
                .build();
    }

    private Notification.Action action(String title, String act, int icon) {
        Intent i = new Intent(this, OverlayService.class).setAction(act);
        PendingIntent pi = PendingIntent.getService(this, act.hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi).build();
    }

    private void refreshNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(1, buildNotification());
    }

    // ---------- views ----------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private void makeResultView() {
        resultView = new ResultView(this);
        resultLp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        resultLp.gravity = Gravity.TOP | Gravity.START;
    }

    private void makeBubble() {
        bubble = new TextView(this);
        bubble.setText("RC");
        bubble.setTextColor(Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xCC2979FF);
        bubble.setBackground(bg);
        bubbleLp = new WindowManager.LayoutParams(dp(52), dp(52),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = 0;
        bubbleLp.y = dp(120);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bubbleLp.x; sy = bubbleLp.y;
                        tx = e.getRawX(); ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) moved = true;
                        if (moved && bubbleShown) {
                            bubbleLp.x = sx + (int) dx;
                            bubbleLp.y = sy + (int) dy;
                            wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) scan();
                        return true;
                }
                return false;
            }
        });
    }

    // ---------- ON / OFF ----------
    private void showBubble() {
        if (bubbleShown) return;
        if (capture == null) {
            Toast.makeText(this, "Screen capture nahi mila. App kholke START dabao", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            capture.ensure();
        } catch (Exception e) {
            Toast.makeText(this, "Capture shuru nahi hua: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        wm.addView(resultView, resultLp);
        wm.addView(bubble, bubbleLp);
        bubbleShown = true;
        refreshNotification();
    }

    private void hideBubble() {
        if (!bubbleShown) return;
        resultView.set(new ArrayList<NameMatch.Item>(), "");
        try { wm.removeView(bubble); } catch (Exception ignored) {}
        try { wm.removeView(resultView); } catch (Exception ignored) {}
        bubbleShown = false;
        if (capture != null) capture.pause();
        refreshNotification();
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (bubbleShown && capture != null) {
            try { capture.ensure(); } catch (Exception ignored) {}
        }
    }

    // ---------- scan (har tap pe, bina delay) ----------
    private void scan() {
        if (busy || capture == null || !bubbleShown) return;
        busy = true;
        Bitmap full = null;
        try { full = capture.grab(); } catch (Exception ignored) {}
        if (full == null) {
            busy = false;
            Toast.makeText(this, "Frame nahi mila, dobara tap karo", Toast.LENGTH_SHORT).show();
            return;
        }
        int W = full.getWidth(), H = full.getHeight();
        if (W < H) {
            resultView.set(new ArrayList<NameMatch.Item>(), "Room screen kholo");
            busy = false;
            return;
        }
        final int cx = (int) (NameMatch.CROP_L * W), cy = (int) (NameMatch.CROP_T * H);
        final int cw = (int) ((NameMatch.CROP_R - NameMatch.CROP_L) * W);
        final int ch = (int) ((NameMatch.CROP_B - NameMatch.CROP_T) * H);
        Bitmap crop = Bitmap.createBitmap(full, cx, cy, cw, ch);
        bubble.setText("..");
        recognizer.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener(text -> {
                    List<NameMatch.Item> items = NameMatch.evaluate(text, cw, ch);
                    int g = 0, y = 0, r = 0;
                    for (NameMatch.Item it : items) {
                        it.rect.offset(cx, cy);
                        if (it.status == NameMatch.GREEN) g++;
                        else if (it.status == NameMatch.RED) r++;
                        else y++;
                    }
                    resultView.set(items, "G" + g + "  R" + r + "  Y" + y);
                    bubble.setText("RC");
                    busy = false;
                })
                .addOnFailureListener(e -> {
                    bubble.setText("RC");
                    busy = false;
                });
    }

    // ---------- KILL ----------
    private void kill() {
        killed = true;
        Registry.clear();
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        try { if (bubbleShown) wm.removeView(bubble); } catch (Exception ignored) {}
        try { if (bubbleShown) wm.removeView(resultView); } catch (Exception ignored) {}
        bubbleShown = false;
        if (capture != null) capture.release();
        if (recognizer != null) recognizer.close();
        Registry.clear();
        super.onDestroy();
        if (killed) Process.killProcess(Process.myPid()); // pura refresh
    }
}
