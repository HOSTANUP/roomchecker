package com.roomchecker.app;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Room ke naam vs registered list.
 * Symbols hata ke bache hue akshar compare hote hain. GREEN = lagbhag pura match,
 * RED = kisi registered se milta hi nahi (ya kisi registered ki copy jaisa), baaki sab YELLOW.
 */
public class NameMatch {
    public static final int GREEN = 0, YELLOW = 1, RED = 2;
    // Room list ka bada area; asli list slot numbers se dhoondhi jaati hai
    public static final double CROP_L = 0.25, CROP_R = 1.0, CROP_T = 0.205, CROP_B = 0.745;

    public static class Item {
        public Rect rect;
        public int status;
    }

    private static class Alias { int serial; String n; }
    private static class Group {
        int col, cy;
        Rect box;
        List<Text.Line> lines = new ArrayList<>();
        String raw = "", n = "";
        boolean clean;
        int serial = -1, status = YELLOW;
    }
    private static class Pair { Group g; Alias a; double s; int max; }

    private static final String SC_FROM = "\u1D00\u0299\u1D04\u1D05\u1D07\uA730\u0262\u029C\u026A\u1D0A\u1D0B\u029F\u1D0D\u0274\u1D0F\u1D18\u01EB\u0280\uA731\u1D1B\u1D1C\u1D20\u1D21\u028F\u1D22";
    private static final String SC_TO = "abcdefghijklmnopqrstuvwyz";

    /** Stylish/leet naam ko simple form mein badalta hai (4nup == Anup). */
    public static String norm(String s) {
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFKD);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int k = SC_FROM.indexOf(c);
            if (k >= 0) c = SC_TO.charAt(k);
            c = Character.toLowerCase(c);
            switch (c) {
                case '4': c = 'a'; break;
                case '0': c = 'o'; break;
                case '3': c = 'e'; break;
                case '1': case 'l': case '!': case '|': c = 'i'; break;
                case '5': case '$': c = 's'; break;
                case '7': c = 't'; break;
                case '8': c = 'b'; break;
                default: break;
            }
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) sb.append(c);
        }
        return sb.toString();
    }

    private static int lcs(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) cur[j] = prev[j - 1] + 1;
                else cur[j] = Math.max(prev[j], cur[j - 1]);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    /** 0..1: kitne akshar (sequence mein) common hain. */
    private static double sim(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        if (a.equals(b)) return 1.0;
        double s = 2.0 * lcs(a, b) / (a.length() + b.length());
        String shorter = a.length() <= b.length() ? a : b;
        String longer = a.length() <= b.length() ? b : a;
        if (shorter.length() >= 3 && longer.contains(shorter)) s = Math.max(s, 0.7);
        return s;
    }

    private static List<Alias> buildAliases() {
        List<Alias> out = new ArrayList<>();
        for (Map.Entry<Integer, String> e : Registry.names.entrySet()) {
            String raw = e.getValue();
            if (raw == null) continue;
            String full = norm(raw);
            if (!full.isEmpty()) addAlias(out, e.getKey(), full);
            String[] parts = raw.split("[/|]");
            if (parts.length > 1) {
                for (String p : parts) {
                    String n = norm(p);
                    if (n.length() >= 3 && !n.equals(full)) addAlias(out, e.getKey(), n);
                }
            }
        }
        return out;
    }

    private static void addAlias(List<Alias> out, int serial, String n) {
        Alias a = new Alias();
        a.serial = serial;
        a.n = n;
        out.add(a);
    }

    // ---------- room ke naam dhoondhna ----------
    private static List<Text.Line> collect(Text text, int h) {
        List<Text.Line> out = new ArrayList<>();
        for (Text.TextBlock b : text.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                Rect bb = l.getBoundingBox();
                if (bb == null) continue;
                if (bb.top < 3 || bb.bottom > h - 3) continue; // kata hua row
                out.add(l);
            }
        }
        return out;
    }

    private static double meanLeft(List<Text.Line> c) {
        double s = 0;
        for (Text.Line l : c) s += l.getBoundingBox().left;
        return s / c.size();
    }

    /** Slot numbers (1,2,3..) ke do columns dhoondh ke, har number ke saamne wala naam uthata hai. */
    private static List<Group> anchored(List<Text.Line> all, int w, int h) {
        List<Text.Line> nums = new ArrayList<>();
        for (Text.Line l : all) {
            String t = l.getText().trim();
            if (t.matches("\\d{1,2}")) {
                int v = Integer.parseInt(t);
                if (v >= 1 && v <= 60) nums.add(l);
            }
        }
        if (nums.size() < 4) return null;
        Collections.sort(nums, new Comparator<Text.Line>() {
            @Override public int compare(Text.Line a, Text.Line b) {
                return a.getBoundingBox().left - b.getBoundingBox().left;
            }
        });
        List<List<Text.Line>> cols = new ArrayList<>();
        for (Text.Line l : nums) {
            List<Text.Line> cur = cols.isEmpty() ? null : cols.get(cols.size() - 1);
            if (cur != null && l.getBoundingBox().left - cur.get(0).getBoundingBox().left <= 0.03 * w) {
                cur.add(l);
            } else {
                List<Text.Line> c = new ArrayList<>();
                c.add(l);
                cols.add(c);
            }
        }
        Collections.sort(cols, new Comparator<List<Text.Line>>() {
            @Override public int compare(List<Text.Line> a, List<Text.Line> b) { return b.size() - a.size(); }
        });
        if (cols.size() < 2 || cols.get(1).size() < 2) return null;
        List<Text.Line> c1 = cols.get(0), c2 = cols.get(1);
        double m1 = meanLeft(c1), m2 = meanLeft(c2);
        if (m1 > m2) {
            List<Text.Line> tc = c1; c1 = c2; c2 = tc;
            double tm = m1; m1 = m2; m2 = tm;
        }
        double cellW = m2 - m1;
        if (cellW < 0.15 * w) return null;
        Set<Text.Line> numSet = new HashSet<>(c1);
        numSet.addAll(c2);
        double rowTol = 0.05 * h;
        List<Group> groups = new ArrayList<>();
        for (int ci = 0; ci < 2; ci++) {
            List<Text.Line> c = ci == 0 ? c1 : c2;
            for (Text.Line n : c) {
                Rect nb = n.getBoundingBox();
                double zl = nb.right + 0.005 * w;
                double zr = ci == 0 ? m2 - 0.01 * w : m2 + cellW;
                Group g = null;
                for (Text.Line l : all) {
                    if (numSet.contains(l)) continue;
                    Rect bb = l.getBoundingBox();
                    if (Math.abs(bb.centerY() - nb.centerY()) > rowTol) continue;
                    if (bb.centerX() < zl || bb.centerX() > zr) continue;
                    if (g == null) {
                        g = new Group();
                        g.col = ci;
                        g.cy = nb.centerY();
                        g.box = new Rect(bb);
                    } else {
                        g.box.union(bb);
                    }
                    g.lines.add(l);
                }
                if (g != null) groups.add(g);
            }
        }
        return groups;
    }

    /** Backup: slot numbers na padhe jaayein toh purana tarika (fixed jagah). */
    private static List<Group> fixed(List<Text.Line> all, int w, int h) {
        double span = CROP_R - CROP_L;
        double zl0 = (0.350 - CROP_L) / span, zl1 = (0.392 - CROP_L) / span;
        double zr0 = (0.650 - CROP_L) / span, zr1 = (0.692 - CROP_L) / span;
        double split = (0.665 - CROP_L) / span;
        double rowTol = 0.05 * h;
        List<Group> groups = new ArrayList<>();
        for (Text.Line l : all) {
            Rect bb = l.getBoundingBox();
            String t = l.getText().trim();
            double fx = bb.centerX() / (double) w;
            boolean inL = fx >= zl0 && fx <= zl1, inR = fx >= zr0 && fx <= zr1;
            if (t.matches("\\d{1,2}") && (inL || inR)) continue;
            int col = fx < split ? 0 : 1;
            Group g = null;
            for (Group x : groups) {
                if (x.col == col && Math.abs(x.cy - bb.centerY()) <= rowTol) { g = x; break; }
            }
            if (g == null) {
                g = new Group();
                g.col = col;
                g.cy = bb.centerY();
                g.box = new Rect(bb);
                groups.add(g);
            } else {
                g.box.union(bb);
            }
            g.lines.add(l);
        }
        return groups;
    }

    // ---------- matching ----------
    public static List<Item> evaluate(Text text, int w, int h) {
        List<Text.Line> all = collect(text, h);
        List<Group> groups = anchored(all, w, h);
        if (groups == null) groups = fixed(all, w, h);

        for (Group g : groups) {
            Collections.sort(g.lines, new Comparator<Text.Line>() {
                @Override public int compare(Text.Line a, Text.Line b) {
                    return a.getBoundingBox().left - b.getBoundingBox().left;
                }
            });
            StringBuilder sb = new StringBuilder();
            for (Text.Line l : g.lines) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(l.getText().trim());
            }
            g.raw = sb.toString();
            g.n = norm(g.raw);
            int ascii = 0, tot = 0;
            for (int i = 0; i < g.raw.length(); i++) {
                char c = g.raw.charAt(i);
                if (Character.isWhitespace(c)) continue;
                tot++;
                if (c >= 0x21 && c <= 0x7E) ascii++;
            }
            g.clean = g.n.length() >= 3 && tot > 0 && ascii >= 0.75 * tot;
        }

        List<Alias> aliases = buildAliases();
        List<Pair> pairs = new ArrayList<>();
        for (Group g : groups) {
            if (g.n.isEmpty()) continue;
            for (Alias a : aliases) {
                double s = sim(g.n, a.n);
                if (s >= 0.5) {
                    Pair p = new Pair();
                    p.g = g; p.a = a; p.s = s;
                    p.max = Math.max(g.n.length(), a.n.length());
                    pairs.add(p);
                }
            }
        }
        Collections.sort(pairs, new Comparator<Pair>() {
            @Override public int compare(Pair x, Pair y) {
                if (x.s != y.s) return x.s > y.s ? -1 : 1;
                return y.max - x.max;
            }
        });
        Set<Integer> taken = new HashSet<>();
        Map<Integer, Double> claimedSim = new HashMap<>();
        for (Pair p : pairs) {
            if (p.g.serial != -1 || taken.contains(p.a.serial)) continue;
            p.g.serial = p.a.serial;
            taken.add(p.a.serial);
            claimedSim.put(p.a.serial, p.s);
            int minLen = Math.min(p.g.n.length(), p.a.n.length());
            boolean green = p.s >= 1.0 || (p.s >= 0.94 && minLen >= 6);
            p.g.status = green ? GREEN : YELLOW;
        }

        for (Group g : groups) {
            if (g.serial != -1) continue;
            if (g.n.isEmpty() || aliases.isEmpty() || !g.clean) { g.status = YELLOW; continue; }
            double best = 0;
            int bestSerial = -1;
            for (Alias a : aliases) {
                double s = sim(g.n, a.n);
                if (s > best) { best = s; bestSerial = a.serial; }
            }
            if (best < 0.5) {
                g.status = RED; // kisi registered naam se milta hi nahi
            } else {
                Double cs = claimedSim.get(bestSerial);
                // milta-julta naam, par asli (exact) match kisi aur slot ko mil chuka hai
                g.status = (cs != null && cs >= 1.0) ? RED : YELLOW;
            }
        }

        List<Item> out = new ArrayList<>();
        for (Group g : groups) {
            Item it = new Item();
            it.rect = new Rect(g.box.left - 8, g.box.top - 5, g.box.right + 8, g.box.bottom + 5);
            it.status = g.status;
            out.add(it);
        }
        return out;
    }
}
