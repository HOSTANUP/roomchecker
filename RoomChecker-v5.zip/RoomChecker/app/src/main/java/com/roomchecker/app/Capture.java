package com.roomchecker.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.nio.ByteBuffer;

/**
 * Screen capture. Latest frame hamesha ready rehta hai, isliye tap pe grab() turant milta hai.
 * Rotation pe display apne aap dobara banta hai.
 */
public class Capture {
    private final WindowManager wm;
    private final Object lock = new Object();
    private final HandlerThread ht;
    private final Handler bg;
    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private Image held;
    private int capW, capH;

    public Capture(Context ctx, WindowManager wm, int resultCode, Intent data) {
        this.wm = wm;
        ht = new HandlerThread("rc-cap");
        ht.start();
        bg = new Handler(ht.getLooper());
        MediaProjectionManager mpm = (MediaProjectionManager) ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(resultCode, data);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { releaseDisplay(); }
        }, new Handler(Looper.getMainLooper()));
    }

    /** Capture shuru karo (ya screen size badli ho toh dobara banao). */
    public void ensure() {
        if (projection == null) return;
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        if (vd != null && dm.widthPixels == capW && dm.heightPixels == capH) return;
        releaseDisplay();
        capW = dm.widthPixels;
        capH = dm.heightPixels;
        reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader r) {
                Image n = null;
                try { n = r.acquireLatestImage(); } catch (Exception ignored) {}
                if (n == null) return;
                synchronized (lock) {
                    if (held != null) held.close();
                    held = n;
                }
            }
        }, bg);
        vd = projection.createVirtualDisplay("rc", capW, capH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
    }

    /** Sabse naya frame, turant. Null agar abhi tak koi frame nahi aaya. */
    public Bitmap grab() {
        ensure();
        synchronized (lock) {
            if (held == null) return null;
            Image.Plane p = held.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int w = held.getWidth(), h = held.getHeight();
            int pixelStride = p.getPixelStride();
            int rowPadding = p.getRowStride() - pixelStride * w;
            Bitmap bmp = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888);
            buf.rewind();
            bmp.copyPixelsFromBuffer(buf);
            if (rowPadding != 0) {
                Bitmap c = Bitmap.createBitmap(bmp, 0, 0, w, h);
                bmp.recycle();
                bmp = c;
            }
            return bmp;
        }
    }

    /** OFF: capture band, par permission bani rehti hai. */
    public void pause() { releaseDisplay(); }

    private void releaseDisplay() {
        if (vd != null) { vd.release(); vd = null; }
        synchronized (lock) {
            if (held != null) { held.close(); held = null; }
        }
        if (reader != null) {
            reader.setOnImageAvailableListener(null, null);
            reader.close();
            reader = null;
        }
    }

    public void release() {
        releaseDisplay();
        if (projection != null) {
            MediaProjection p = projection;
            projection = null;
            p.stop();
        }
        ht.quitSafely();
    }
}
