package com.roomchecker.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Poori screen pe touch-through overlay: naam ke upar halka green/yellow/red. */
public class ResultView extends View {
    private List<NameMatch.Item> items = new ArrayList<>();
    private String summary = "";
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ResultView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        text.setColor(Color.WHITE);
        text.setTextSize(42f);
        text.setFakeBoldText(true);
        pill.setColor(0xB0000000);
    }

    public void set(List<NameMatch.Item> list, String s) {
        items = list;
        summary = s;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        if (!summary.isEmpty()) {
            float x = getWidth() * 0.02f, y = getHeight() * 0.5f;
            float w = text.measureText(summary);
            cv.drawRoundRect(new RectF(x - 12, y - 52, x + w + 12, y + 18), 16, 16, pill);
            cv.drawText(summary, x, y, text);
        }
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        cv.translate(-loc[0], -loc[1]);
        for (NameMatch.Item it : items) {
            int base = it.status == NameMatch.GREEN ? 0x00E676
                    : it.status == NameMatch.RED ? 0xFF1744 : 0xFFEB3B;
            fill.setColor(0x55000000 | base);
            stroke.setColor(0xCC000000 | base);
            RectF r = new RectF(it.rect);
            cv.drawRoundRect(r, 10, 10, fill);
            cv.drawRoundRect(r, 10, 10, stroke);
        }
    }
}
