package com.roomchecker.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Poori screen pe touch-through overlay: naam ke upar halka green/yellow/red + corner mein chhota info panel. */
public class ResultView extends View {
    private List<NameMatch.Item> items = new ArrayList<>();
    private List<String> info = new ArrayList<>();
    private String summary = "";
    private boolean infoVisible = true;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint head = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint small = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint box = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgeText = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ResultView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        head.setColor(Color.WHITE);
        head.setTextSize(30f);
        head.setFakeBoldText(true);
        small.setTextSize(19f);
        small.setSubpixelText(true);
        box.setColor(0xF2101216);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(1.5f);
        border.setColor(0x66FFFFFF);
        badge.setColor(0xFFFFEB3B);
        badgeText.setColor(Color.BLACK);
        badgeText.setTextSize(20f);
        badgeText.setFakeBoldText(true);
    }

    public void set(List<NameMatch.Item> list, String s) {
        items = list;
        summary = s;
        if (s.isEmpty()) info = new ArrayList<>();
        invalidate();
    }

    public void setInfo(List<String> lines) {
        info = lines;
        invalidate();
    }

    public void setInfoVisible(boolean v) {
        infoVisible = v;
        invalidate();
    }

    public boolean hasMarks() { return !items.isEmpty() || !summary.isEmpty(); }

    /** Line ka pehla akshar rang batata hai: y = yellow naam, h = hint, p = nahi dikhe list. */
    private int colorFor(char k) {
        if (k == 'y') return 0xFFFFEB3B;
        if (k == 'h') return 0xFF80DEEA;
        if (k == 'p') return 0xFFCFD8DC;
        return Color.WHITE;
    }

    /** Lambi line ko panel ki chaudai mein todta hai (poora naam dikhe, kate nahi). */
    private List<String[]> wrap(float avail) {
        List<String[]> out = new ArrayList<>();
        for (String raw : info) {
            if (raw.isEmpty()) continue;
            String kind = raw.substring(0, 1);
            String body = raw.substring(1);
            boolean first = true;
            while (!body.isEmpty() && out.size() < 24) {
                String pre = first ? "" : "   ";
                float av = avail - (first ? 0f : small.measureText(pre));
                int n = small.breakText(body, true, av, null);
                if (n <= 0) n = 1;
                if (n < body.length()) {
                    int sp = -1;
                    for (int i = n - 1; i >= n / 2; i--) {
                        char ch = body.charAt(i);
                        if (ch == ' ' || ch == '/') { sp = i + 1; break; }
                    }
                    if (sp > 0) n = sp;
                    if (n < body.length() && n > 0 && Character.isHighSurrogate(body.charAt(n - 1))) n--;
                    if (n <= 0) n = 1;
                }
                out.add(new String[]{kind, pre + body.substring(0, n).trim()});
                body = body.substring(n).replaceFirst("^\\s+", "");
                first = false;
            }
        }
        return out;
    }

    @Override
    protected void onDraw(Canvas cv) {
        if (!summary.isEmpty()) {
            float x = 6f, y0 = 6f;
            if (infoVisible) {
                float maxW = Math.min(getWidth() * 0.30f, 480f);
                float lineH = 24f;
                List<String[]> lines = wrap(maxW - 20);
                float h = 40f + lineH * lines.size() + 8f;
                RectF r = new RectF(x, y0, x + maxW, y0 + h);
                cv.drawRoundRect(r, 10, 10, box);
                cv.drawRoundRect(r, 10, 10, border);
                cv.drawText(summary, x + 10, y0 + 31, head);
                for (int i = 0; i < lines.size(); i++) {
                    small.setColor(colorFor(lines.get(i)[0].charAt(0)));
                    cv.drawText(lines.get(i)[1], x + 10, y0 + 40 + lineH * (i + 1) - 6, small);
                }
            } else {
                float w = head.measureText(summary);
                RectF r = new RectF(x, y0, x + w + 20, y0 + 42);
                cv.drawRoundRect(r, 10, 10, box);
                cv.drawText(summary, x + 10, y0 + 31, head);
            }
        }
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        cv.translate(-loc[0], -loc[1]);
        for (NameMatch.Item it : items) {
            int base = it.status == NameMatch.GREEN ? 0x00E676
                    : it.status == NameMatch.RED ? 0xFF1744 : 0xFFEB3B;
            fill.setColor(0x55000000 | base);
            stroke.setColor(0xCC000000 | base);
            RectF r = new RectF(it.rect);
            cv.drawRoundRect(r, 10, 10, fill);
            cv.drawRoundRect(r, 10, 10, stroke);
            if (it.tag > 0) {
                cv.drawCircle(r.left, r.top, 13, badge);
                String t = String.valueOf(it.tag);
                cv.drawText(t, r.left - badgeText.measureText(t) / 2, r.top + 7, badgeText);
            }
        }
    }
}
