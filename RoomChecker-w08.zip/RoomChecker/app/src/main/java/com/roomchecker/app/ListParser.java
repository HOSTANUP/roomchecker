package com.roomchecker.app;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** BattleX11 "Match Details" screenshot se serial -> naam nikalta hai. */
public class ListParser {
    private static final Pattern SERIAL_ONLY = Pattern.compile("^\\s*(\\d{1,2})\\s*[.,:]?\\s*$");
    private static final Pattern SERIAL_NAME = Pattern.compile("^\\s*(\\d{1,2})\\s*[.,:]\\s*(.+)$");

    private static class Row {
        int serial, cy;
        String inline = "";
        List<Text.Line> parts = new ArrayList<>();
    }

    public static Map<Integer, String> parse(Text text, int w, int h) {
        List<Row> rows = new ArrayList<>();
        List<Text.Line> others = new ArrayList<>();
        for (Text.TextBlock b : text.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                Rect bb = l.getBoundingBox();
                if (bb == null) continue;
                int cy = bb.centerY();
                if (cy < 0.10 * h || cy > 0.88 * h) continue; // header / JOIN bar
                String t = l.getText();
                if (bb.left < 0.2 * w) {
                    Matcher m1 = SERIAL_ONLY.matcher(t);
                    if (m1.matches()) {
                        Row r = new Row();
                        r.serial = Integer.parseInt(m1.group(1));
                        r.cy = cy;
                        rows.add(r);
                        continue;
                    }
                    Matcher m2 = SERIAL_NAME.matcher(t);
                    if (m2.matches()) {
                        Row r = new Row();
                        r.serial = Integer.parseInt(m2.group(1));
                        r.cy = cy;
                        r.inline = m2.group(2).trim();
                        rows.add(r);
                        continue;
                    }
                }
                others.add(l);
            }
        }
        Collections.sort(rows, new Comparator<Row>() {
            @Override public int compare(Row a, Row b) { return a.cy - b.cy; }
        });
        repair(rows);

        double tol = 0.028 * h;
        for (Text.Line l : others) {
            Rect bb = l.getBoundingBox();
            Row best = null;
            double bd = 1e9;
            for (Row r : rows) {
                double d = Math.abs(bb.centerY() - r.cy);
                if (d < bd) { bd = d; best = r; }
            }
            if (best != null && bd <= tol) best.parts.add(l);
        }
        Map<Integer, String> out = new LinkedHashMap<>();
        for (Row r : rows) {
            Collections.sort(r.parts, new Comparator<Text.Line>() {
                @Override public int compare(Text.Line a, Text.Line b) {
                    return a.getBoundingBox().left - b.getBoundingBox().left;
                }
            });
            StringBuilder sb = new StringBuilder(r.inline);
            for (Text.Line p : r.parts) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(p.getText().trim());
            }
            String name = sb.toString().trim();
            String old = out.get(r.serial);
            if (old == null || (Registry.doubtful(old) && !Registry.doubtful(name))) out.put(r.serial, name);
        }
        return out;
    }

    /** Serial galat padha ho ya poora row chhoot gaya ho, toh padosi serials se theek karta hai. */
    private static void repair(List<Row> rows) {
        for (int i = 1; i < rows.size() - 1; i++) {
            Row a = rows.get(i - 1), r = rows.get(i), b = rows.get(i + 1);
            if (b.serial - a.serial == 2 && r.serial != a.serial + 1) r.serial = a.serial + 1;
        }
        List<Integer> diffs = new ArrayList<>();
        for (int i = 1; i < rows.size(); i++) {
            if (rows.get(i).serial - rows.get(i - 1).serial == 1) diffs.add(rows.get(i).cy - rows.get(i - 1).cy);
        }
        if (diffs.size() < 2) return;
        Collections.sort(diffs);
        double pitch = diffs.get(diffs.size() / 2);
        List<Row> extra = new ArrayList<>();
        for (int i = 1; i < rows.size(); i++) {
            Row a = rows.get(i - 1), b = rows.get(i);
            double d = b.cy - a.cy;
            if (b.serial - a.serial == 2 && d > 1.6 * pitch && d < 2.4 * pitch) {
                Row m = new Row();
                m.serial = a.serial + 1;
                m.cy = (a.cy + b.cy) / 2;
                extra.add(m);
            }
        }
        rows.addAll(extra);
    }
}
