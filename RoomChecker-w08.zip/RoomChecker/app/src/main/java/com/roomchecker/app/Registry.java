package com.roomchecker.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Registered list: RAM mein, aur Save dabane pe phone mein bhi. Sirf KILL pe wipe hota hai. */
public class Registry {
    public static final TreeMap<Integer, String> names = new TreeMap<>();
    /** Har naam ko screen jaisa render karke OCR ne jo padha (look-alike akshar ke liye). */
    public static final HashMap<Integer, String> seen = new HashMap<>();
    private static final String PREFS = "rc_saved";

    public static int count() { return names.size(); }
    public static int maxSerial() { return names.isEmpty() ? 0 : names.lastKey(); }
    public static void clear() { names.clear(); seen.clear(); }

    /** Khali ya jisme normalize ke baad kuch bacha hi nahi: padha nahi ja sakta. */
    public static boolean doubtful(String s) {
        return s == null || NameMatch.norm(s).isEmpty();
    }

    public static List<Integer> missing() {
        List<Integer> m = new ArrayList<>();
        for (int i = 1; i <= maxSerial(); i++) if (!names.containsKey(i)) m.add(i);
        return m;
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ');
    }

    public static boolean hasSaved(Context c) {
        String n = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("names", "");
        return n != null && !n.isEmpty();
    }

    /** Naam + unka look + approve kiye hue naam: phone ki storage mein. */
    public static void save(Context c) {
        StringBuilder n = new StringBuilder();
        for (Map.Entry<Integer, String> e : names.entrySet()) {
            n.append(e.getKey()).append('\t').append(clean(e.getValue())).append('\n');
        }
        StringBuilder s = new StringBuilder();
        for (Map.Entry<Integer, String> e : seen.entrySet()) {
            s.append(e.getKey()).append('\t').append(clean(e.getValue())).append('\n');
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("names", n.toString())
                .putString("seen", s.toString())
                .putString("approved", NameMatch.exportApprovals())
                .commit();
    }

    public static void saveApprovals(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("approved", NameMatch.exportApprovals())
                .apply();
    }

    /** App phir se khule ya phone restart ho: saved naam wapas. */
    public static void loadIfEmpty(Context c) {
        if (!names.isEmpty()) return;
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        readInto(sp.getString("names", ""), names);
        readInto(sp.getString("seen", ""), seen);
        NameMatch.importApprovals(sp.getString("approved", ""));
    }

    private static void readInto(String data, Map<Integer, String> out) {
        if (data == null) return;
        for (String line : data.split("\n")) {
            int t = line.indexOf('\t');
            if (t <= 0) continue;
            try {
                out.put(Integer.parseInt(line.substring(0, t)), line.substring(t + 1));
            } catch (Exception ignored) { }
        }
    }

    /** KILL: RAM bhi aur phone mein saved bhi, sab saaf. */
    public static void wipe(Context c) {
        clear();
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit();
    }
}
