package com.roomchecker.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextPaint;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Poori screen pe touch-through overlay: naam ke upar halka green/yellow/red + yellow ka number badge. */
public class ResultView extends View {
    private List<NameMatch.Item> items = new ArrayList<>();
    private String summary = "";
    // true = panel window dikh raha hai; false = sirf chhota G/R/Y pill
    private boolean infoVisible = true;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint head = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint box = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgeText = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ResultView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        head.setColor(Color.WHITE);
        head.setTextSize(30f);
        head.setFakeBoldText(true);
        box.setColor(0xF2101216);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(1.5f);
        border.setColor(0x66FFFFFF);
        badge.setColor(0xFFFFEB3B);
        badgeText.setColor(Color.BLACK);
        badgeText.setTextSize(20f);
        badgeText.setFakeBoldText(true);
    }

    public void set(List<NameMatch.Item> list, String s) {
        items = list;
        summary = s;
        invalidate();
    }

    /** Purana tareeka (ab panel alag window hai): kuch nahi karta. */
    public void setInfo(List<String> lines) { }

    public void setInfoVisible(boolean v) {
        infoVisible = v;
        invalidate();
    }

    public boolean hasMarks() { return !items.isEmpty() || !summary.isEmpty(); }

    @Override
    protected void onDraw(Canvas cv) {
        if (!summary.isEmpty() && !infoVisible) {
            float w = head.measureText(summary);
            RectF r = new RectF(6f, 6f, 6f + w + 20, 6f + 42);
            cv.drawRoundRect(r, 10, 10, box);
            cv.drawRoundRect(r, 10, 10, border);
            cv.drawText(summary, 16f, 37f, head);
        }
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        cv.translate(-loc[0], -loc[1]);
        for (NameMatch.Item it : items) {
            int base = it.status == NameMatch.GREEN ? 0x00E676
                    : it.status == NameMatch.RED ? 0xFF1744 : 0xFFEB3B;
            fill.setColor(0x55000000 | base);
            stroke.setColor(0xCC000000 | base);
            RectF r = new RectF(it.rect);
            cv.drawRoundRect(r, 10, 10, fill);
            cv.drawRoundRect(r, 10, 10, stroke);
            if (it.tag > 0) {
                cv.drawCircle(r.left, r.top, 13, badge);
                String t = String.valueOf(it.tag);
                cv.drawText(t, r.left - badgeText.measureText(t) / 2, r.top + 7, badgeText);
            }
        }
    }
}
