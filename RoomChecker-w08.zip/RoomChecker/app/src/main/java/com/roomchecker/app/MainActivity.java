package com.roomchecker.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int CAPTURE = 12;
    private TextView summary;
    private LinearLayout grid;
    private TextRecognizer recognizer;
    private boolean dirty = false;
    private boolean learning = false;
    private int learnIdx = 0;
    private final List<Integer> learnQueue = new ArrayList<>();

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        Registry.loadIfEmpty(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(26), dp(10), dp(8));

        TextView title = new TextView(this);
        title.setText("Room Checker");
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        Button pasteBtn = new Button(this);
        pasteBtn.setText("Naam paste karo");
        pasteBtn.setAllCaps(false);
        pasteBtn.setOnClickListener(v -> pasteList());
        Button saveBtn = new Button(this);
        saveBtn.setText("Save");
        saveBtn.setAllCaps(false);
        saveBtn.setOnClickListener(v -> saveNow());
        top.addView(pasteBtn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f));
        top.addView(saveBtn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(top);

        summary = new TextView(this);
        summary.setTextSize(13);
        summary.setPadding(dp(2), dp(4), dp(2), dp(4));
        root.addView(summary);

        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        root.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button start = new Button(this);
        start.setText("START");
        start.setOnClickListener(v -> startOverlay());
        root.addView(start);

        setContentView(root);
        refresh();
        learn();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    // ---------- list: saare naam ek hi screen pe (2 column) ----------
    private void refresh() {
        int doubt = 0;
        for (String s : Registry.names.values()) if (Registry.doubtful(s)) doubt++;
        String st;
        if (Registry.count() == 0) {
            st = "Naam paste karo, phir Save dabao.";
        } else {
            boolean ok = !dirty && Registry.hasSaved(this);
            st = "Naam: " + Registry.count() + "     "
                    + (ok ? "Save ho gaya \u2713 (KILL tak rahenge)" : "\u26A0 Save nahi hua, Save dabao");
        }
        if (doubt > 0) st += "\nPadhe nahi gaye (yellow): " + doubt;
        summary.setText(st);
        buildGrid(Registry.maxSerial());
    }

    private void buildGrid(int n) {
        grid.removeAllViews();
        if (n == 0) return;
        int rows = (n + 1) / 2;
        float sp = rows <= 24 ? 12f : 10f;
        for (int i = 0; i < rows; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            if (i % 2 == 1) row.setBackgroundColor(0x0F000000);
            grid.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            row.addView(cell(i + 1, sp), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            row.addView(cell(i + 1 + rows, sp), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
    }

    private TextView cell(final int serial, float sp) {
        TextView t = new TextView(this);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(4), 0, dp(4), 0);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (serial > Registry.maxSerial()) return t;
        String name = Registry.names.get(serial);
        if (name == null) {
            t.setText(serial + ". -");
            t.setBackgroundColor(0x44F44336);
        } else if (Registry.doubtful(name)) {
            t.setText(serial + ". " + name);
            t.setBackgroundColor(0x55FFC107);
        } else {
            t.setText(serial + ". " + name);
        }
        t.setOnClickListener(v -> edit(serial));
        return t;
    }

    private void edit(final int serial) {
        final EditText et = new EditText(this);
        String cur = Registry.names.get(serial);
        et.setText(cur == null ? "" : cur);
        new AlertDialog.Builder(this)
                .setTitle("Slot " + serial)
                .setView(et)
                .setPositiveButton("OK", (d, w) -> {
                    Registry.names.put(serial, et.getText().toString().trim());
                    Registry.seen.remove(serial);
                    dirty = true;
                    refresh();
                    learn();
                })
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Unreadable", (d, w) -> {
                    Registry.names.put(serial, "");
                    dirty = true;
                    refresh();
                })
                .show();
    }

    // ---------- paste + save ----------
    /** Clipboard se naam: hosting panel ("Player: NAME") ya "1. naam" / "naam" lines. */
    private void pasteList() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip().getItemCount() == 0) {
            Toast.makeText(this, "Clipboard khali hai", Toast.LENGTH_SHORT).show();
            return;
        }
        String all = cm.getPrimaryClip().getItemAt(0).coerceToText(this).toString();
        Pattern player = Pattern.compile("^Player\\s*:\\s*(.+)$", Pattern.CASE_INSENSITIVE);
        Pattern numbered = Pattern.compile("^(\\d{1,2})\\s*[.)\\-:]\\s*(.+)$");
        boolean panelFormat = Pattern.compile("(?im)^\\s*Player\\s*:").matcher(all).find();
        Registry.clear();
        int auto = 0, count = 0;
        for (String line : all.split("\\r?\\n")) {
            String t = line.trim();
            if (t.isEmpty()) continue;
            if (panelFormat) {
                Matcher pm = player.matcher(t);
                if (pm.matches()) {
                    Registry.names.put(++auto, pm.group(1).trim());
                    count++;
                }
                continue;
            }
            Matcher m = numbered.matcher(t);
            int serial;
            String name;
            if (m.matches()) {
                serial = Integer.parseInt(m.group(1));
                name = m.group(2).trim();
                auto = serial;
            } else {
                serial = ++auto;
                name = t;
            }
            Registry.names.put(serial, name);
            count++;
        }
        dirty = true;
        refresh();
        Toast.makeText(this, count + " naam paste hue. Ab Save dabao", Toast.LENGTH_SHORT).show();
        learn();
    }

    private void saveNow() {
        if (Registry.count() == 0) {
            Toast.makeText(this, "Pehle naam paste karo", Toast.LENGTH_SHORT).show();
            return;
        }
        Registry.save(this);
        dirty = false;
        Toast.makeText(this, "Save ho gaya (" + Registry.count() + " naam). KILL dabane tak rahenge", Toast.LENGTH_LONG).show();
        refresh();
    }

    // ---------- naam ka look seekhna (look-alike akshar ke liye) ----------
    private void learn() {
        if (learning) return;
        learnQueue.clear();
        for (Map.Entry<Integer, String> e : Registry.names.entrySet()) {
            String v = e.getValue();
            if (v != null && !v.trim().isEmpty() && !Registry.seen.containsKey(e.getKey())) learnQueue.add(e.getKey());
        }
        if (learnQueue.isEmpty()) return;
        learnIdx = 0;
        learning = true;
        learnNext();
    }

    private void learnNext() {
        if (learnIdx >= learnQueue.size()) {
            learning = false;
            if (!dirty && Registry.hasSaved(this)) Registry.save(this);
            refresh();
            learn();
            return;
        }
        final int serial = learnQueue.get(learnIdx);
        String name = Registry.names.get(serial);
        summary.setText("Naam ka look seekh raha hu: " + (learnIdx + 1) + " / " + learnQueue.size());
        if (name == null) {
            Registry.seen.put(serial, "");
            learnIdx++;
            learnNext();
            return;
        }
        recognizer.process(InputImage.fromBitmap(renderName(name), 0))
                .addOnSuccessListener(t -> {
                    Registry.seen.put(serial, t.getText().replace('\n', ' '));
                    learnIdx++;
                    learnNext();
                })
                .addOnFailureListener(e -> {
                    Registry.seen.put(serial, "");
                    learnIdx++;
                    learnNext();
                });
    }

    private Bitmap renderName(String s) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setTextSize(56f);
        int w = (int) Math.min(2400, Math.max(200, p.measureText(s) + 80));
        Bitmap b = Bitmap.createBitmap(w, 120, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.WHITE);
        c.drawText(s, 40, 80, p);
        return b;
    }

    // ---------- START ----------
    private void startOverlay() {
        if (learning) {
            Toast.makeText(this, "Naam seekh raha hu, 2-3 second ruko", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Registry.count() == 0) {
            Toast.makeText(this, "Pehle naam paste karke Save karo", Toast.LENGTH_SHORT).show();
            return;
        }
        if (dirty || !Registry.hasSaved(this)) {
            Registry.save(this);   // START se pehle apne aap save
            dirty = false;
            refresh();
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'Draw over other apps' ON karo, phir wapas aake START dabao", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), CAPTURE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != CAPTURE) return;
        if (res == RESULT_OK && data != null) {
            Intent svc = new Intent(this, OverlayService.class);
            svc.putExtra("code", res);
            svc.putExtra("data", data);
            startForegroundService(svc);
            finish();
        } else {
            Toast.makeText(this, "Screen capture allow karna zaroori hai", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        recognizer.close();
        super.onDestroy();
    }
}
