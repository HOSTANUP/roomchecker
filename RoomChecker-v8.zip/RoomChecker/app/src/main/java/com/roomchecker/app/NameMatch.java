package com.roomchecker.app;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Room ke naam vs registered list.
 * Symbols hata ke bache hue akshar compare hote hain. GREEN = lagbhag pura match,
 * RED = kisi registered se milta hi nahi (ya kisi registered ki copy jaisa), baaki sab YELLOW.
 */
public class NameMatch {
    public static final int GREEN = 0, YELLOW = 1, RED = 2;
    // Room list ka bada area; asli list slot numbers se dhoondhi jaati hai
    public static final double CROP_L = 0.25, CROP_R = 1.0, CROP_T = 0.17, CROP_B = 0.78;
    // list ke andar naam ka text kahan tak poora dikhta hai (screen height ke hisse mein)
    public static final double LIST_TOP = 0.195, LIST_BOT_L = 0.735, LIST_BOT_R = 0.755;

    public static class Item {
        public Rect rect;
        public int status;
    }

    private static class Alias { int serial; String n; }
    private static class El { String t; Rect bb; }
    private static class Group {
        int col, cy;
        Rect box;
        List<El> lines = new ArrayList<>();
        String raw = "", n = "";
        boolean clean;
        int serial = -1, status = YELLOW;
    }
    private static class Pair { Group g; Alias a; double s; int max; }

    private static final String SC_FROM = "\u1D00\u0299\u1D04\u1D05\u1D07\uA730\u0262\u029C\u026A\u1D0A\u1D0B\u029F\u1D0D\u0274\u1D0F\u1D18\u01EB\u0280\uA731\u1D1B\u1D1C\u1D20\u1D21\u028F\u1D22";
    private static final String SC_TO = "abcdefghijklmnopqrstuvwyz";

    // look-alike letters: (non-latin letter)(latin letter) jodiyon mein
    private static final Map<Character, Character> CF = new HashMap<>();
    static {
        String s = "\u13AAa\u13F4b\u13DFc\u13A0d\u13ACe\u13C0g\u13BBh\u13ABj\u13E6k\u13DEl\u13B7m\u13E2p\u13A1r\u13DAs\u13A2t\u13D9v\u13B3w\u13C3z\u13A9y"
                + "\u0430a\u0435e\u043Eo\u0440p\u0441c\u0443y\u0445x\u043Ak\u043Cm\u043Dh\u0442t\u0432b"
                + "\u0410a\u0412b\u0415e\u041Ak\u041Cm\u041Dh\u041Eo\u0420p\u0421c\u0422t\u0425x\u0423y"
                + "\u03B1a\u03B2b\u03B5e\u03B9i\u03BAk\u03BDv\u03BFo\u03C1p\u03C3o\u03C4t\u03C5u\u03C9w\u03C7x"
                + "\u0391a\u0392b\u0395e\u0396z\u0397h\u0399i\u039Ak\u039Cm\u039Dn\u039Fo\u03A1p\u03A4t\u03A7x\u03A5y"
                + "\u03A3e\u03B7n\u10E7y\u0251a\u0261g\u0131i"
                + "\u15E9a\u15F7b\u1455c\u15EAd\u15F4e\u15B4f\u161Cg\u157Ch\u148Dj\u14AAl\u15F0m\u144En\u146Dp\u1587r\u1515s\u144Cu\u142Fv\u15EFw";
        for (int i = 0; i + 1 < s.length(); i += 2) CF.put(s.charAt(i), s.charAt(i + 1));
    }

    /** Stylish/leet naam ko simple form mein badalta hai (4nup == Anup). */
    public static String norm(String s) {
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFKD);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int k = SC_FROM.indexOf(c);
            if (k >= 0) c = SC_TO.charAt(k);
            Character cf = CF.get(c);
            if (cf != null) c = cf;
            c = Character.toLowerCase(c);
            switch (c) {
                case '4': c = 'a'; break;
                case '0': c = 'o'; break;
                case '3': c = 'e'; break;
                case '1': case 'l': case '!': case '|': c = 'i'; break;
                case '5': case '$': c = 's'; break;
                case '7': c = 't'; break;
                case '8': c = 'b'; break;
                default: break;
            }
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) sb.append(c);
        }
        return sb.toString();
    }

    private static int lcs(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) cur[j] = prev[j - 1] + 1;
                else cur[j] = Math.max(prev[j], cur[j - 1]);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    /** 0..1: kitne akshar (sequence mein) common hain. */
    private static double sim(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        if (a.equals(b)) return 1.0;
        double s = 2.0 * lcs(a, b) / (a.length() + b.length());
        String shorter = a.length() <= b.length() ? a : b;
        String longer = a.length() <= b.length() ? b : a;
        if (shorter.length() >= 3 && longer.contains(shorter)) s = Math.max(s, 0.7);
        return s;
    }

    private static List<Alias> buildAliases() {
        List<Alias> out = new ArrayList<>();
        for (Map.Entry<Integer, String> e : Registry.names.entrySet()) {
            String raw = e.getValue();
            if (raw == null) continue;
            String full = norm(raw);
            if (!full.isEmpty()) addAlias(out, e.getKey(), full);
            String[] parts = raw.split("[/|]");
            if (parts.length > 1) {
                for (String p : parts) {
                    String n = norm(p);
                    if (n.length() >= 3 && !n.equals(full)) addAlias(out, e.getKey(), n);
                }
            }
        }
        return out;
    }

    private static void addAlias(List<Alias> out, int serial, String n) {
        Alias a = new Alias();
        a.serial = serial;
        a.n = n;
        out.add(a);
    }

    // ---------- room ke naam dhoondhna (shabd-level: ML Kit ke line-merge se farak nahi padta) ----------
    private static List<El> elements(Text text) {
        List<El> out = new ArrayList<>();
        for (Text.TextBlock b : text.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                for (Text.Element e : l.getElements()) {
                    Rect bb = e.getBoundingBox();
                    if (bb == null) continue;
                    El x = new El();
                    x.t = e.getText();
                    x.bb = bb;
                    out.add(x);
                }
            }
        }
        return out;
    }

    private static double meanLeft(List<El> c) {
        double s = 0;
        for (El e : c) s += e.bb.left;
        return s / c.size();
    }

    private static double meanRight(List<El> c) {
        double s = 0;
        for (El e : c) s += e.bb.right;
        return s / c.size();
    }

    private static int median(List<Integer> v) {
        Collections.sort(v);
        return v.get(v.size() / 2);
    }

    // pichhli baar ke columns (width ke hisse mein): agar is baar slot numbers na padhe jaayein
    private static double[] lastGeom = null;

    /** Slot numbers ke do columns: {m1, nr1, m2, nr2} = left/right edge ka average. */
    private static double[] geom(List<El> all, int w) {
        List<El> nums = new ArrayList<>();
        for (El e : all) {
            String t = e.t.trim();
            if (t.matches("\\d{1,2}")) {
                int v = Integer.parseInt(t);
                if (v >= 1 && v <= 60) nums.add(e);
            }
        }
        double[] res = null;
        if (nums.size() >= 4) {
            Collections.sort(nums, new Comparator<El>() {
                @Override public int compare(El a, El b) { return a.bb.left - b.bb.left; }
            });
            List<List<El>> cols = new ArrayList<>();
            for (El e : nums) {
                List<El> cur = cols.isEmpty() ? null : cols.get(cols.size() - 1);
                if (cur != null && e.bb.left - cur.get(0).bb.left <= 0.03 * w) {
                    cur.add(e);
                } else {
                    List<El> c = new ArrayList<>();
                    c.add(e);
                    cols.add(c);
                }
            }
            Collections.sort(cols, new Comparator<List<El>>() {
                @Override public int compare(List<El> a, List<El> b) { return b.size() - a.size(); }
            });
            if (cols.size() >= 2 && cols.get(1).size() >= 2) {
                List<El> c1 = cols.get(0), c2 = cols.get(1);
                double m1 = meanLeft(c1), m2 = meanLeft(c2);
                double r1 = meanRight(c1), r2 = meanRight(c2);
                if (m1 > m2) {
                    double t = m1; m1 = m2; m2 = t;
                    t = r1; r1 = r2; r2 = t;
                }
                if (m2 - m1 >= 0.15 * w) res = new double[]{m1, r1, m2, r2};
            }
        }
        if (res != null) {
            lastGeom = new double[]{res[0] / w, res[1] / w, res[2] / w, res[3] / w};
            return res;
        }
        if (lastGeom != null) {
            return new double[]{lastGeom[0] * w, lastGeom[1] * w, lastGeom[2] * w, lastGeom[3] * w};
        }
        return null;
    }

    /**
     * Numbers sirf columns ki jagah batate hain. Har naam (text ki har line) alag player hai:
     * solo mein 1 naam per slot, duo mein 2, squad mein 4. Kate hue rows chhod diye jaate hain.
     */
    private static List<Group> anchored(List<El> all, int w, int h) {
        double[] g = geom(all, w);
        if (g == null) return null;
        double m1 = g[0], nr1 = g[1], m2 = g[2], nr2 = g[3];
        double cellW = m2 - m1;
        double span = CROP_B - CROP_T;
        double yTop = (LIST_TOP - CROP_T) / span * h;
        double tol = 0.03 / span * h;
        List<Group> groups = new ArrayList<>();
        for (int ci = 0; ci < 2; ci++) {
            double zl = (ci == 0 ? nr1 : nr2) + 0.005 * w;
            double zr = ci == 0 ? m2 - 0.01 * w : m2 + cellW;
            double yBot = ((ci == 0 ? LIST_BOT_L : LIST_BOT_R) - CROP_T) / span * h;
            List<El> col = new ArrayList<>();
            for (El e : all) {
                double cx = e.bb.centerX();
                if (cx < zl || cx > zr) continue;
                if (e.bb.top < yTop || e.bb.bottom > yBot) continue;
                col.add(e);
            }
            Collections.sort(col, new Comparator<El>() {
                @Override public int compare(El a, El b) { return a.bb.centerY() - b.bb.centerY(); }
            });
            Group cur = null;
            int lastCy = 0;
            for (El e : col) {
                if (cur == null || e.bb.centerY() - lastCy > tol) {
                    cur = new Group();
                    cur.col = ci;
                    cur.cy = e.bb.centerY();
                    cur.box = new Rect(e.bb);
                    groups.add(cur);
                } else {
                    cur.box.union(e.bb);
                }
                cur.lines.add(e);
                lastCy = e.bb.centerY();
            }
        }
        return groups;
    }

    // ---------- matching ----------
    public static List<Item> evaluate(Text text, int w, int h) {
        List<Group> groups = anchored(elements(text), w, h);
        if (groups == null) return new ArrayList<Item>();

        for (Group g : groups) {
            Collections.sort(g.lines, new Comparator<El>() {
                @Override public int compare(El a, El b) { return a.bb.left - b.bb.left; }
            });
            StringBuilder sb = new StringBuilder();
            for (El l : g.lines) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(l.t.trim());
            }
            g.raw = sb.toString();
            g.n = norm(g.raw);
            int ascii = 0, tot = 0;
            for (int i = 0; i < g.raw.length(); i++) {
                char c = g.raw.charAt(i);
                if (Character.isWhitespace(c)) continue;
                tot++;
                if (c >= 0x21 && c <= 0x7E) ascii++;
            }
            g.clean = g.n.length() >= 3 && tot > 0 && ascii >= 0.75 * tot;
        }

        List<Alias> aliases = buildAliases();
        List<Pair> pairs = new ArrayList<>();
        for (Group g : groups) {
            if (g.n.isEmpty()) continue;
            for (Alias a : aliases) {
                double s = sim(g.n, a.n);
                if (s >= 0.5) {
                    Pair p = new Pair();
                    p.g = g; p.a = a; p.s = s;
                    p.max = Math.max(g.n.length(), a.n.length());
                    pairs.add(p);
                }
            }
        }
        Collections.sort(pairs, new Comparator<Pair>() {
            @Override public int compare(Pair x, Pair y) {
                if (x.s != y.s) return x.s > y.s ? -1 : 1;
                return y.max - x.max;
            }
        });
        Set<Integer> taken = new HashSet<>();
        Map<Integer, Double> claimedSim = new HashMap<>();
        for (Pair p : pairs) {
            if (p.g.serial != -1 || taken.contains(p.a.serial)) continue;
            p.g.serial = p.a.serial;
            taken.add(p.a.serial);
            claimedSim.put(p.a.serial, p.s);
            int minLen = Math.min(p.g.n.length(), p.a.n.length());
            boolean green = p.s >= 1.0 || (p.s >= 0.9 && minLen >= 8) || (p.s >= 0.94 && minLen >= 6);
            p.g.status = green ? GREEN : YELLOW;
        }

        for (Group g : groups) {
            if (g.serial != -1) continue;
            if (g.n.isEmpty() || aliases.isEmpty() || !g.clean) { g.status = YELLOW; continue; }
            double best = 0;
            int bestSerial = -1;
            for (Alias a : aliases) {
                double s = sim(g.n, a.n);
                if (s > best) { best = s; bestSerial = a.serial; }
            }
            if (best < 0.5) {
                g.status = RED; // kisi registered naam se milta hi nahi
            } else {
                Double cs = claimedSim.get(bestSerial);
                // milta-julta naam, par asli (exact) match kisi aur slot ko mil chuka hai
                g.status = (cs != null && cs >= 1.0) ? RED : YELLOW;
            }
        }

        List<Item> out = new ArrayList<>();
        for (Group g : groups) {
            Item it = new Item();
            it.rect = new Rect(g.box.left - 8, g.box.top - 5, g.box.right + 8, g.box.bottom + 5);
            it.status = g.status;
            out.add(it);
        }
        return out;
    }
}
