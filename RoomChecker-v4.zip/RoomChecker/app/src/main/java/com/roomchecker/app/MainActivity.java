package com.roomchecker.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int PICK = 11;
    private static final int CAPTURE = 12;
    private TextView summary;
    private Button pickBtn;
    private BaseAdapter adapter;
    private TextRecognizer recognizer;
    private final List<Uri> queue = new ArrayList<>();
    private int done = 0;
    private boolean warned = false;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(30), dp(14), dp(14));

        TextView title = new TextView(this);
        title.setText("Room Checker - Stage 2");
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        pickBtn = new Button(this);
        pickBtn.setText("Registered list ke screenshots chuno (4-5)");
        pickBtn.setAllCaps(false);
        pickBtn.setOnClickListener(v -> pick());
        root.addView(pickBtn);

        summary = new TextView(this);
        summary.setPadding(0, dp(8), 0, dp(8));
        root.addView(summary);

        ListView lv = new ListView(this);
        adapter = new BaseAdapter() {
            @Override public int getCount() { return Registry.maxSerial(); }
            @Override public Object getItem(int i) { return i + 1; }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View cv, ViewGroup p) {
                TextView tv = new TextView(MainActivity.this);
                tv.setPadding(dp(10), dp(9), dp(10), dp(9));
                tv.setTextSize(16);
                int serial = i + 1;
                String n = Registry.names.get(serial);
                if (n == null) {
                    tv.setText(serial + ".  (nahi mila - tap karke likho)");
                    tv.setBackgroundColor(0x44F44336);
                } else if (Registry.doubtful(n)) {
                    tv.setText(serial + ".  (padha nahi gaya)  " + n);
                    tv.setBackgroundColor(0x55FFC107);
                } else {
                    tv.setText(serial + ".  " + n);
                    tv.setBackgroundColor(Color.TRANSPARENT);
                }
                return tv;
            }
        };
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((AdapterView<?> a, View v, int pos, long id) -> edit(pos + 1));
        root.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bottom = new LinearLayout(this);
        Button clear = new Button(this);
        clear.setText("List saaf karo");
        clear.setAllCaps(false);
        clear.setOnClickListener(v -> { Registry.clear(); warned = false; refresh(); });
        Button start = new Button(this);
        start.setText("START");
        start.setOnClickListener(v -> startOverlay());
        bottom.addView(clear, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottom.addView(start, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(bottom);

        setContentView(root);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(Intent.createChooser(i, "Screenshots chuno"), PICK);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == CAPTURE) {
            if (res == RESULT_OK && data != null) {
                Intent svc = new Intent(this, OverlayService.class);
                svc.putExtra("code", res);
                svc.putExtra("data", data);
                startForegroundService(svc);
                finish();
            } else {
                Toast.makeText(this, "Screen capture allow karna zaroori hai", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (req != PICK || res != RESULT_OK || data == null) return;
        queue.clear();
        ClipData cd = data.getClipData();
        if (cd != null) {
            for (int i = 0; i < cd.getItemCount(); i++) queue.add(cd.getItemAt(i).getUri());
        } else if (data.getData() != null) {
            queue.add(data.getData());
        }
        done = 0;
        pickBtn.setEnabled(false);
        next();
    }

    private void next() {
        if (done >= queue.size()) {
            pickBtn.setEnabled(true);
            refresh();
            return;
        }
        summary.setText("Padh raha hu: " + (done + 1) + " / " + queue.size());
        try {
            InputImage img = InputImage.fromFilePath(this, queue.get(done));
            final int w = img.getWidth();
            final int h = img.getHeight();
            recognizer.process(img)
                    .addOnSuccessListener(text -> { merge(ListParser.parse(text, w, h)); done++; next(); })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Ek screenshot nahi padha gaya", Toast.LENGTH_SHORT).show();
                        done++;
                        next();
                    });
        } catch (IOException e) {
            done++;
            next();
        }
    }

    private void merge(Map<Integer, String> found) {
        for (Map.Entry<Integer, String> e : found.entrySet()) {
            String old = Registry.names.get(e.getKey());
            if (old == null || (Registry.doubtful(old) && !Registry.doubtful(e.getValue()))) {
                Registry.names.put(e.getKey(), e.getValue());
            }
        }
    }

    private void refresh() {
        int doubt = 0;
        for (String s : Registry.names.values()) if (Registry.doubtful(s)) doubt++;
        List<Integer> miss = Registry.missing();
        String s = "Mile: " + Registry.count() + " / " + Registry.maxSerial();
        if (!miss.isEmpty()) s += "\nNahi mile: " + miss;
        if (doubt > 0) s += "\nPadhe nahi gaye (yellow): " + doubt;
        s += "\nKisi row pe tap karke naam theek kar sakte ho.";
        summary.setText(s);
        adapter.notifyDataSetChanged();
    }

    private void edit(final int serial) {
        final EditText et = new EditText(this);
        String cur = Registry.names.get(serial);
        et.setText(cur == null ? "" : cur);
        new AlertDialog.Builder(this)
                .setTitle("Slot " + serial)
                .setView(et)
                .setPositiveButton("Save", (d, w) -> {
                    Registry.names.put(serial, et.getText().toString().trim());
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Unreadable", (d, w) -> {
                    Registry.names.put(serial, "");
                    refresh();
                })
                .show();
    }

    private void startOverlay() {
        if (Registry.count() == 0) {
            Toast.makeText(this, "Pehle registered list lo", Toast.LENGTH_SHORT).show();
            return;
        }
        List<Integer> miss = Registry.missing();
        if (!miss.isEmpty() && !warned) {
            warned = true;
            Toast.makeText(this, "Kuch slots missing hain. Phir bhi chalana ho toh START dobara dabao", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'Draw over other apps' ON karo, phir wapas aake START dabao", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), CAPTURE);
    }

    @Override
    protected void onDestroy() {
        recognizer.close();
        super.onDestroy();
    }
}
