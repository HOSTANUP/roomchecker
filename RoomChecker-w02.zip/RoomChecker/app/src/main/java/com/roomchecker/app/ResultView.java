package com.roomchecker.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextUtils;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Poori screen pe touch-through overlay: naam ke upar halka green/yellow/red + chhota info panel. */
public class ResultView extends View {
    private List<NameMatch.Item> items = new ArrayList<>();
    private List<String> info = new ArrayList<>();
    private String summary = "";
    private boolean infoVisible = true;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgeText = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ResultView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        text.setColor(Color.WHITE);
        text.setTextSize(40f);
        text.setFakeBoldText(true);
        small.setColor(Color.WHITE);
        small.setTextSize(24f);
        pill.setColor(0xC8000000);
        badge.setColor(0xFFFFEB3B);
        badgeText.setColor(Color.BLACK);
        badgeText.setTextSize(22f);
        badgeText.setFakeBoldText(true);
    }

    public void set(List<NameMatch.Item> list, String s) {
        items = list;
        summary = s;
        if (s.isEmpty()) info = new ArrayList<>();
        invalidate();
    }

    public void setInfo(List<String> lines) {
        info = lines;
        invalidate();
    }

    public void setInfoVisible(boolean v) {
        infoVisible = v;
        invalidate();
    }

    public boolean hasMarks() { return !items.isEmpty() || !summary.isEmpty(); }

    @Override
    protected void onDraw(Canvas cv) {
        if (!summary.isEmpty()) {
            if (infoVisible) {
                float x = getWidth() * 0.045f, y0 = getHeight() * 0.19f;
                float maxW = getWidth() * 0.28f;
                float lineH = 30f;
                float h = 56f + lineH * info.size() + 12f;
                cv.drawRoundRect(new RectF(x, y0, x + maxW, y0 + h), 16, 16, pill);
                cv.drawText(summary, x + 12, y0 + 42, text);
                for (int i = 0; i < info.size(); i++) {
                    String line = TextUtils.ellipsize(info.get(i), small, maxW - 24, TextUtils.TruncateAt.END).toString();
                    cv.drawText(line, x + 12, y0 + 56 + lineH * (i + 1) - 8, small);
                }
            } else {
                float x = getWidth() * 0.02f, y = getHeight() * 0.5f;
                float w = text.measureText(summary);
                cv.drawRoundRect(new RectF(x - 12, y - 52, x + w + 12, y + 18), 16, 16, pill);
                cv.drawText(summary, x, y, text);
            }
        }
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        cv.translate(-loc[0], -loc[1]);
        for (NameMatch.Item it : items) {
            int base = it.status == NameMatch.GREEN ? 0x00E676
                    : it.status == NameMatch.RED ? 0xFF1744 : 0xFFEB3B;
            fill.setColor(0x55000000 | base);
            stroke.setColor(0xCC000000 | base);
            RectF r = new RectF(it.rect);
            cv.drawRoundRect(r, 10, 10, fill);
            cv.drawRoundRect(r, 10, 10, stroke);
            if (it.tag > 0) {
                cv.drawCircle(r.left, r.top, 15, badge);
                String t = String.valueOf(it.tag);
                cv.drawText(t, r.left - badgeText.measureText(t) / 2, r.top + 8, badgeText);
            }
        }
    }
}
