package com.roomchecker.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

/** Registered list: sirf RAM mein. KILL pe clear() hota hai. */
public class Registry {
    public static final TreeMap<Integer, String> names = new TreeMap<>();
    /** Har naam ko screen jaisa render karke OCR ne jo padha (look-alike akshar ke liye). */
    public static final HashMap<Integer, String> seen = new HashMap<>();

    public static int count() { return names.size(); }
    public static int maxSerial() { return names.isEmpty() ? 0 : names.lastKey(); }
    public static void clear() { names.clear(); seen.clear(); }

    /** Khali ya jisme normalize ke baad kuch bacha hi nahi: padha nahi ja sakta. */
    public static boolean doubtful(String s) {
        return s == null || NameMatch.norm(s).isEmpty();
    }

    public static List<Integer> missing() {
        List<Integer> m = new ArrayList<>();
        for (int i = 1; i <= maxSerial(); i++) if (!names.containsKey(i)) m.add(i);
        return m;
    }
}
