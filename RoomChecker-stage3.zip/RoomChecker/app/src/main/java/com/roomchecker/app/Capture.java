package com.roomchecker.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.nio.ByteBuffer;

/** Screen capture (MediaProjection). Rotation pe display apne aap dobara banta hai. */
public class Capture {
    private final WindowManager wm;
    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private int capW, capH;
    private Bitmap last;

    public Capture(Context ctx, WindowManager wm, int resultCode, Intent data) {
        this.wm = wm;
        MediaProjectionManager mpm = (MediaProjectionManager) ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(resultCode, data);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { releaseDisplay(); }
        }, new Handler(Looper.getMainLooper()));
    }

    /** Latest frame, ya null agar abhi koi frame nahi aaya. */
    public Bitmap grab() {
        if (projection == null) return null;
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        if (vd == null || dm.widthPixels != capW || dm.heightPixels != capH) {
            releaseDisplay();
            capW = dm.widthPixels;
            capH = dm.heightPixels;
            reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
            vd = projection.createVirtualDisplay("rc", capW, capH, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
            last = null;
        }
        Image img = reader.acquireLatestImage();
        if (img != null) {
            try {
                Image.Plane p = img.getPlanes()[0];
                ByteBuffer buf = p.getBuffer();
                int pixelStride = p.getPixelStride();
                int rowPadding = p.getRowStride() - pixelStride * capW;
                Bitmap bmp = Bitmap.createBitmap(capW + rowPadding / pixelStride, capH, Bitmap.Config.ARGB_8888);
                bmp.copyPixelsFromBuffer(buf);
                if (rowPadding != 0) {
                    Bitmap c = Bitmap.createBitmap(bmp, 0, 0, capW, capH);
                    bmp.recycle();
                    bmp = c;
                }
                last = bmp;
            } finally {
                img.close();
            }
        }
        return last;
    }

    private void releaseDisplay() {
        if (vd != null) { vd.release(); vd = null; }
        if (reader != null) { reader.close(); reader = null; }
    }

    public void release() {
        releaseDisplay();
        if (projection != null) {
            MediaProjection p = projection;
            projection = null;
            p.stop();
        }
    }
}
