package com.roomchecker.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.ArrayList;
import java.util.List;

public class OverlayService extends Service {
    private WindowManager wm;
    private TextView bubble, status;
    private LinearLayout panel;
    private ResultView resultView;
    private WindowManager.LayoutParams bubbleLp, panelLp;
    private boolean panelShown = false;
    private boolean live = false;
    private boolean busy = false;
    private Capture capture;
    private TextRecognizer recognizer;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        if (i != null && i.hasExtra("code") && capture == null) {
            try {
                int code = i.getIntExtra("code", 0);
                Intent data = i.getParcelableExtra("data");
                capture = new Capture(this, wm, code, data);
            } catch (Exception e) {
                Toast.makeText(this, "Screen capture shuru nahi hua: " + e.getMessage(), Toast.LENGTH_LONG).show();
                stopSelf();
            }
        }
        return START_NOT_STICKY;
    }

    @Override public void onCreate() {
        super.onCreate();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        makeResultView();
        makeBubble();
        makePanel();
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("rc", "Room Checker", NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this, "rc")
                .setContentTitle("Room Checker chal raha hai")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private WindowManager.LayoutParams lp(int w, int h) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }

    private void makeResultView() {
        resultView = new ResultView(this);
        WindowManager.LayoutParams rp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        rp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(resultView, rp);
    }

    private void makeBubble() {
        bubble = new TextView(this);
        bubble.setText("RC");
        bubble.setTextColor(Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xCC2979FF);
        bubble.setBackground(bg);
        bubbleLp = lp(dp(52), dp(52));
        bubbleLp.x = 0;
        bubbleLp.y = dp(120);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bubbleLp.x; sy = bubbleLp.y;
                        tx = e.getRawX(); ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            bubbleLp.x = sx + (int) dx;
                            bubbleLp.y = sy + (int) dy;
                            wm.updateViewLayout(bubble, bubbleLp);
                            if (panelShown) { placePanel(); wm.updateViewLayout(panel, panelLp); }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel();
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleLp);
    }

    private void makePanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(0xE6101820);
        panel.setBackground(bg);
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setText(statusText());
        panel.addView(status);
        panel.addView(btn("CHECK (1 baar)", 0xFF1565C0, v -> {
            live = false;
            status.setText(statusText());
            hidePanel();
            scan(0, 300);
        }));
        panel.addView(btn("ON (live)", 0xFF2E7D32, v -> {
            live = true;
            status.setText(statusText());
            hidePanel();
            scan(0, 300);
        }));
        panel.addView(btn("OFF", 0xFFF9A825, v -> {
            live = false;
            status.setText(statusText());
            resultView.set(new ArrayList<NameMatch.Item>(), "");
        }));
        panel.addView(btn("KILL APP", 0xFFC62828, v -> kill()));
        panelLp = lp(dp(160), WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private String statusText() {
        return (live ? "ON" : "OFF") + " | List: " + Registry.count();
    }

    private Button btn(String t, int color, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        g.setColor(color);
        b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        p.topMargin = dp(5);
        b.setLayoutParams(p);
        b.setOnClickListener(c);
        return b;
    }

    private void placePanel() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int right = bubbleLp.x + dp(58);
        panelLp.x = (right + dp(160) > dm.widthPixels) ? bubbleLp.x - dp(166) : right;
        int maxY = dm.heightPixels - dp(260);
        panelLp.y = Math.max(0, Math.min(bubbleLp.y, maxY));
    }

    private void togglePanel() {
        if (panelShown) hidePanel(); else showPanel();
    }

    private void showPanel() {
        if (panelShown) return;
        status.setText(statusText());
        placePanel();
        wm.addView(panel, panelLp);
        panelShown = true;
    }

    private void hidePanel() {
        if (!panelShown) return;
        wm.removeView(panel);
        panelShown = false;
    }

    // ---------- checking ----------
    private void scan(final int tries, long delayMs) {
        if (busy || capture == null) return;
        busy = true;
        handler.postDelayed(new Runnable() {
            @Override public void run() { doScan(tries); }
        }, delayMs);
    }

    private void doScan(final int tries) {
        Bitmap full = null;
        try { full = capture.grab(); } catch (Exception ignored) {}
        if (full == null) {
            busy = false;
            if (tries < 8) scan(tries + 1, 250); // pehla frame aane ka wait
            return;
        }
        int W = full.getWidth(), H = full.getHeight();
        if (W < H) {
            resultView.set(new ArrayList<NameMatch.Item>(), "Room screen kholo");
            busy = false;
            if (live) scan(0, 600);
            return;
        }
        final int cx = (int) (NameMatch.CROP_L * W), cy = (int) (NameMatch.CROP_T * H);
        final int cw = (int) ((NameMatch.CROP_R - NameMatch.CROP_L) * W);
        final int ch = (int) ((NameMatch.CROP_B - NameMatch.CROP_T) * H);
        Bitmap crop = Bitmap.createBitmap(full, cx, cy, cw, ch);
        recognizer.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener(text -> {
                    List<NameMatch.Item> items = NameMatch.evaluate(text, cw, ch);
                    int g = 0, y = 0, r = 0;
                    for (NameMatch.Item it : items) {
                        it.rect.offset(cx, cy);
                        if (it.status == NameMatch.GREEN) g++;
                        else if (it.status == NameMatch.RED) r++;
                        else y++;
                    }
                    resultView.set(items, "G" + g + "  R" + r + "  Y" + y);
                    busy = false;
                    if (live) scan(0, 120);
                })
                .addOnFailureListener(e -> {
                    busy = false;
                    if (live) scan(0, 500);
                });
    }

    private void kill() {
        live = false;
        Registry.clear();
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        live = false;
        handler.removeCallbacksAndMessages(null);
        try { if (panelShown) wm.removeView(panel); } catch (Exception ignored) {}
        try { wm.removeView(bubble); } catch (Exception ignored) {}
        try { wm.removeView(resultView); } catch (Exception ignored) {}
        panelShown = false;
        if (capture != null) capture.release();
        if (recognizer != null) recognizer.close();
        super.onDestroy();
    }
}
