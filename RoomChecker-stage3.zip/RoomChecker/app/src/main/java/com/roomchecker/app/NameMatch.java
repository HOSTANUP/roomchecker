package com.roomchecker.app;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Room ke naam vs registered list. Rule: RED sirf tab jab pakka ho, warna YELLOW. */
public class NameMatch {
    public static final int GREEN = 0, YELLOW = 1, RED = 2;
    // Free Fire room list ka area (poori screen ke hisse, landscape)
    public static final double CROP_L = 0.34, CROP_R = 0.965, CROP_T = 0.19, CROP_B = 0.72;

    public static class Item {
        public Rect rect;
        public int status;
    }

    private static class Alias { int serial; String n; }
    private static class Group {
        int col, cy;
        Rect box;
        List<Text.Line> lines = new ArrayList<>();
        String raw = "", n = "";
        boolean clean;
        int serial = -1, dist = 99, status = YELLOW;
    }
    private static class Pair { Group g; Alias a; int d, max; }

    // small-caps letters -> normal letters
    private static final String SC_FROM = "\u1D00\u0299\u1D04\u1D05\u1D07\uA730\u0262\u029C\u026A\u1D0A\u1D0B\u029F\u1D0D\u0274\u1D0F\u1D18\u01EB\u0280\uA731\u1D1B\u1D1C\u1D20\u1D21\u028F\u1D22";
    private static final String SC_TO = "abcdefghijklmnopqrstuvwyz";

    /** Stylish/leet naam ko ek simple form mein badalta hai (4nup == Anup). */
    public static String norm(String s) {
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFKD);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int k = SC_FROM.indexOf(c);
            if (k >= 0) c = SC_TO.charAt(k);
            c = Character.toLowerCase(c);
            switch (c) {
                case '4': c = 'a'; break;
                case '0': c = 'o'; break;
                case '3': c = 'e'; break;
                case '1': case 'l': case '!': case '|': c = 'i'; break;
                case '5': case '$': c = 's'; break;
                case '7': c = 't'; break;
                case '8': c = 'b'; break;
                default: break;
            }
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) sb.append(c);
        }
        return sb.toString();
    }

    private static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int c = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    private static int allowed(int max) { return max <= 4 ? 0 : (max <= 8 ? 1 : 2); }

    private static List<Alias> buildAliases() {
        List<Alias> out = new ArrayList<>();
        for (Map.Entry<Integer, String> e : Registry.names.entrySet()) {
            String raw = e.getValue();
            if (raw == null) continue;
            String full = norm(raw);
            if (!full.isEmpty()) addAlias(out, e.getKey(), full);
            String[] parts = raw.split("[/|]");
            if (parts.length > 1) {
                for (String p : parts) {
                    String n = norm(p);
                    if (n.length() >= 3 && !n.equals(full)) addAlias(out, e.getKey(), n);
                }
            }
        }
        return out;
    }

    private static void addAlias(List<Alias> out, int serial, String n) {
        Alias a = new Alias();
        a.serial = serial;
        a.n = n;
        out.add(a);
    }

    private static boolean inZone(double fx, double lo, double hi) { return fx >= lo && fx <= hi; }

    public static List<Item> evaluate(Text text, int w, int h) {
        double span = CROP_R - CROP_L;
        double zl0 = (0.350 - CROP_L) / span, zl1 = (0.392 - CROP_L) / span;
        double zr0 = (0.650 - CROP_L) / span, zr1 = (0.692 - CROP_L) / span;
        double split = (0.665 - CROP_L) / span;
        double rowTol = 0.05 * h;

        List<Group> groups = new ArrayList<>();
        for (Text.TextBlock b : text.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                Rect bb = l.getBoundingBox();
                if (bb == null) continue;
                if (bb.top < 3 || bb.bottom > h - 3) continue; // kata hua row
                String t = l.getText().trim();
                double fx = bb.centerX() / (double) w;
                if (t.matches("\\d{1,2}") && (inZone(fx, zl0, zl1) || inZone(fx, zr0, zr1))) continue; // slot number
                int col = fx < split ? 0 : 1;
                Group g = null;
                for (Group x : groups) {
                    if (x.col == col && Math.abs(x.cy - bb.centerY()) <= rowTol) { g = x; break; }
                }
                if (g == null) {
                    g = new Group();
                    g.col = col;
                    g.cy = bb.centerY();
                    g.box = new Rect(bb);
                    groups.add(g);
                } else {
                    g.box.union(bb);
                }
                g.lines.add(l);
            }
        }

        for (Group g : groups) {
            Collections.sort(g.lines, new Comparator<Text.Line>() {
                @Override public int compare(Text.Line a, Text.Line b) {
                    return a.getBoundingBox().left - b.getBoundingBox().left;
                }
            });
            StringBuilder sb = new StringBuilder();
            for (Text.Line l : g.lines) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(l.getText().trim());
            }
            g.raw = sb.toString();
            g.n = norm(g.raw);
            int ascii = 0, tot = 0;
            for (int i = 0; i < g.raw.length(); i++) {
                char c = g.raw.charAt(i);
                if (Character.isWhitespace(c)) continue;
                tot++;
                if (c >= 0x21 && c <= 0x7E) ascii++;
            }
            g.clean = g.n.length() >= 3 && tot > 0 && ascii >= 0.75 * tot;
        }

        List<Alias> aliases = buildAliases();

        // best matches pehle: har registered banda sirf ek slot claim kar sakta hai
        List<Pair> pairs = new ArrayList<>();
        for (Group g : groups) {
            if (g.n.isEmpty()) continue;
            for (Alias a : aliases) {
                int max = Math.max(g.n.length(), a.n.length());
                int d = lev(g.n, a.n);
                if (d <= allowed(max)) {
                    Pair p = new Pair();
                    p.g = g; p.a = a; p.d = d; p.max = max;
                    pairs.add(p);
                }
            }
        }
        Collections.sort(pairs, new Comparator<Pair>() {
            @Override public int compare(Pair x, Pair y) {
                if (x.d != y.d) return x.d - y.d;
                return y.max - x.max;
            }
        });
        Set<Integer> taken = new HashSet<>();
        Map<Integer, Integer> claimedDist = new HashMap<>();
        for (Pair p : pairs) {
            if (p.g.serial != -1 || taken.contains(p.a.serial)) continue;
            p.g.serial = p.a.serial;
            p.g.dist = p.d;
            taken.add(p.a.serial);
            claimedDist.put(p.a.serial, p.d);
            boolean green = p.d == 0 || (p.max >= 7 && (p.d <= 1 || (p.max >= 10 && p.d <= 2)));
            p.g.status = green ? GREEN : YELLOW;
        }

        for (Group g : groups) {
            if (g.serial != -1) continue;
            if (g.n.isEmpty() || aliases.isEmpty() || !g.clean) { g.status = YELLOW; continue; }
            double bestSim = 0;
            Alias best = null;
            for (Alias a : aliases) {
                int max = Math.max(g.n.length(), a.n.length());
                double sim = 1.0 - lev(g.n, a.n) / (double) max;
                if (sim > bestSim) { bestSim = sim; best = a; }
            }
            if (bestSim < 0.6 || best == null) {
                g.status = RED; // registered kisi naam se milta hi nahi
            } else {
                Integer cd = claimedDist.get(best.serial);
                // milta-julta naam, par asli (exact) match kisi aur slot ko mil chuka hai
                g.status = (cd != null && cd == 0) ? RED : YELLOW;
            }
        }

        List<Item> out = new ArrayList<>();
        for (Group g : groups) {
            Item it = new Item();
            it.rect = new Rect(g.box.left - 8, g.box.top - 5, g.box.right + 8, g.box.bottom + 5);
            it.status = g.status;
            out.add(it);
        }
        return out;
    }
}
