package com.roomchecker.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Poori screen pe touch-through overlay: naam ke upar halka green/yellow/red + corner mein chhota info panel. */
public class ResultView extends View {
    private List<NameMatch.Item> items = new ArrayList<>();
    private List<String> info = new ArrayList<>();
    private String summary = "";
    private boolean infoVisible = true;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint head = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint small = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint box = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgeText = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ResultView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        head.setColor(Color.WHITE);
        head.setTextSize(30f);
        head.setFakeBoldText(true);
        small.setTextSize(19f);
        small.setSubpixelText(true);
        box.setColor(0xF2101216);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(1.5f);
        border.setColor(0x66FFFFFF);
        badge.setColor(0xFFFFEB3B);
        badgeText.setColor(Color.BLACK);
        badgeText.setTextSize(20f);
        badgeText.setFakeBoldText(true);
    }

    public void set(List<NameMatch.Item> list, String s) {
        items = list;
        summary = s;
        if (s.isEmpty()) info = new ArrayList<>();
        invalidate();
    }

    public void setInfo(List<String> lines) {
        info = lines;
        invalidate();
    }

    public void setInfoVisible(boolean v) {
        infoVisible = v;
        invalidate();
    }

    public boolean hasMarks() { return !items.isEmpty() || !summary.isEmpty(); }

    /** Line ka pehla akshar rang batata hai: y = yellow naam, h = hint, p = nahi dikhe list. */
    private int colorFor(char k) {
        if (k == 'y') return 0xFFFFEB3B;
        if (k == 'h') return 0xFF80DEEA;
        if (k == 'p') return 0xFFCFD8DC;
        return Color.WHITE;
    }

    @Override
    protected void onDraw(Canvas cv) {
        if (!summary.isEmpty()) {
            float x = 6f, y0 = 6f;
            if (infoVisible) {
                float maxW = Math.min(getWidth() * 0.26f, 420f);
                float lineH = 24f;
                float h = 40f + lineH * info.size() + 8f;
                RectF r = new RectF(x, y0, x + maxW, y0 + h);
                cv.drawRoundRect(r, 10, 10, box);
                cv.drawRoundRect(r, 10, 10, border);
                cv.drawText(summary, x + 10, y0 + 31, head);
                for (int i = 0; i < info.size(); i++) {
                    String raw = info.get(i);
                    if (raw.isEmpty()) continue;
                    small.setColor(colorFor(raw.charAt(0)));
                    String line = TextUtils.ellipsize(raw.substring(1), small, maxW - 20, TextUtils.TruncateAt.END).toString();
                    cv.drawText(line, x + 10, y0 + 40 + lineH * (i + 1) - 6, small);
                }
            } else {
                float w = head.measureText(summary);
                RectF r = new RectF(x, y0, x + w + 20, y0 + 42);
                cv.drawRoundRect(r, 10, 10, box);
                cv.drawText(summary, x + 10, y0 + 31, head);
            }
        }
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        cv.translate(-loc[0], -loc[1]);
        for (NameMatch.Item it : items) {
            int base = it.status == NameMatch.GREEN ? 0x00E676
                    : it.status == NameMatch.RED ? 0xFF1744 : 0xFFEB3B;
            fill.setColor(0x55000000 | base);
            stroke.setColor(0xCC000000 | base);
            RectF r = new RectF(it.rect);
            cv.drawRoundRect(r, 10, 10, fill);
            cv.drawRoundRect(r, 10, 10, stroke);
            if (it.tag > 0) {
                cv.drawCircle(r.left, r.top, 13, badge);
                String t = String.valueOf(it.tag);
                cv.drawText(t, r.left - badgeText.measureText(t) / 2, r.top + 7, badgeText);
            }
        }
    }
}
